# Azusa — Handoff update (2026-11-20)

**From:** Claude (design and architecture) · **To:** ChatGPT (feature briefs), Agy (specs), Codex (review/implementation)
**Read with:** `AZUSA_HANDOFF.md` — the **revised** handoff (2026-11-08, prototype refinements 2026-11-09), shipped in `azusa-handoff.zip`. **Where this update differs from the handoff, this update wins.**
**Status:** design and docs complete for handoff; **development has not started**.

This update captures everything settled on the hi-fi canvas since the handoff: Team backlog, Sprint planning, Team calendar and the Work item view (story, bug and light-story layouts), the regrouped navigation and the completed Kumiko icon set, plus the data-model changes they required. It is written as deltas against the handoff's section numbers so nothing in the original is lost.

---

## 0. Reading order and source of truth

| Topic | Canonical doc |
|---|---|
| Entities, rules, capacity formula, commitments, metrics | **`docs/azusa-data-model.md` v0.6** — supersedes handoff §7, §8 formulas, §11 and the v0.4 copy |
| Sprint planning, team calendar, capacity UI, overhead, buffers, milestones, flags, Distributed model | **`docs/azusa-sprint-planning-decisions.md`** |
| Work item page and modal, the three layouts (story / light story / bug), severity, checklists, tags, closing / Removed | **`docs/azusa-work-item-view.md`** (its "Related 5p changes" section also supersedes the sprint-planning doc where they differ) |
| Vision, context, way of working, design system basics, stack, sample data, PI board interaction model, card spec | `AZUSA_HANDOFF.md` (unchanged unless noted below) |

The prototype remains a **jumping board**, not a pixel spec (handoff preamble still applies).

**Not yet designed (by choice, for later):** ART program board refresh and the remaining Settings sections — keep the handoff's versions as intent until those features are specified.

---

## 1. Section-by-section deltas to `AZUSA_HANDOFF.md`

### §6 Glossary — additions
| Term | Meaning |
|---|---|
| Sprint Commitment / PI Commitment | Immutable snapshots taken at **Start Sprint** / **Start PI**; plan versions v1/v2/v3 are separate and never overwrite them (as in the handoff §11) |
| Planning style | Team setting: **Owner model** (person load = owned SP vs forecast SP) or **Distributed model** (person load = assigned task hours vs dev hours). Snapshotted per Sprint |
| Overhead reserve | Training / General work **hours** reserved per member per Sprint at PI planning, adjustable at Sprint Planning; overhead tickets draw against it |
| Buffer | Placeholder **SP** for unknown work (bugs, support) held by a member; counts in load, outside the commitment, released at Close Sprint |
| Milestone | Team-level dated marker (release, code freeze…) entered on the Team calendar; red date header |
| Carry-over | Story whose previous Sprint slice was not done; sorted to the top of the Sprint backlog with an amber tint |
| Plan check | Advisory warning shown with the Kumiko **warning** glyph (solid orange triangle, ink "!"), e.g. target after milestone, untasked story in Distributed model |
| Removed | Terminal state for work no longer needed (stories and bugs); requires a reason; excluded from velocity, throughput and say/do |
| DoR / DoD | Definition of Ready / Done: team-template checklists copied into each work item; items are **Not done / Done / N/A** |
| Light story | Story in the Enabler, Estimation or Tech debt category: no user story statement, no DoR |
| Severity | Bug impact, set at triage: S1 Critical · S2 Major · S3 Moderate · S4 Minor. Priority is the backlog rank (no field) |

### §7 Domain model
Replaced by data model v0.6. New or changed entities: Story statement / description / target date / milestone link / owner / blocked / removed reason; **Bug** fields (severity, environment, version, device/OS, **ReproStep**, expected / actual result); **ChecklistItem** + **ChecklistTemplate** (per work-item kind); **Tag** (universal) + **WorkItemTag**; **Buffer** + **BufferDraw**; **OverheadReserve** (was Deduction) + **OverheadTicket**; **SprintCeremony** (dated, replaces CeremonyTemplate as the source of truth); **Meeting** (attendees); **Milestone** now team-level (`scope = train` reserved for the ART board); Team gains `planning_style` and DoR/DoD templates; Absence gains planned overtime hours; workflows gain **Removed**; Feature loses its priority field (rank instead).

### §8 Capacity model
- **Workday = 8.0 h** is the only hours↔days factor. No separate "effective hours" / focus factor (an earlier 6.0 h assumption was removed).
- Sprint dev hours per member = workday × FTE − stand-up − that day's ceremonies and attended meetings − overhead reserve; leave/holiday = 0; half day = half; planned overtime +2 h.
- Velocity used for a Sprint: **Sprint override → PI override → rolling normalized velocity**; value and source are snapshotted at Start Sprint.
- Planned SP = committed + stretch + **buffers**. Load bands unchanged (85–115 % green).
- Per-person load per planning style is in data model v0.6 §4. **Display-only exception:** in the Distributed model a buffer's SP is shown on its holder's hours ring via team hours-per-SP.

### §10 Calendar
- The **Team calendar** (boards 3b / 3c / 3d for 2-, 3-, 4-week Sprints) is the single source of truth for leave and is where Sprint capacity is edited: Days off / Dev hours views, per-person totals, vs PI / vs Sprint columns, commitment chips.
- Leave is **always dated** ("reserve a day" is parked on a placeholder date and moved later).
- Ceremonies are entered **per Sprint with dates** (no fixed-day template). Meetings list attendees.
- Four tables under the grid, 2 × 2: **Holidays + Milestones**, **Scrum ceremonies + Meetings**.
- **Milestones:** click a working date in the header → modal (add; edit/remove existing with ✕). Solid red date header, taking precedence over the ceremony tint. Team-level for now.

### §11 Workflows, plan versions, commitments and execution history
- Story flow: New → Active → Quality Check → Acceptance → Closed, plus **Removed** (done-type, not completed work).
- **Bug flow:** Triage → Investigating → Correcting → Verification → Closed, plus **Removed**. The handoff's Not needed / Not reproducible become Removed reasons; Transferred = Move to team; On hold = the Blocked flag.
- **Close** checks AC (where the layout has it) + DoD items still *Not done* (N/A is fine) and asks "Close anyway?" — advisory, like all plan checks. Actual SP is still confirmed at Close Sprint.

### §12 Metrics
- **Say/do counts committed items only.** Stretch, buffers and **Removed** items are excluded (removed items never count, even if removed after Start Sprint).
- Velocity and throughput exclude buffers and Removed items.
- Flags (derived): **missed target** (today > target, item before Acceptance / Verification), **aging** (time in column; amber ≥ 3 d, red ≥ 5 d), **blocked** (stored).
- Later bug metrics can now use **severity** and **environment**.

### §13 Screens
**§13.10 "Screens not yet designed" — status:** the work-item **details modal** (opened from the card's expand button) and **Sprint Planning** are now designed (below). Still to design: the **Start Sprint / Close Sprint** review dialogs, Train dashboard, the remaining Settings sections, Feature/Project management views, Backup/restore UI. §13.9 (PI board interaction model) and §13.11 (card spec) are unchanged. New screens:

**13.12 Team backlog (5b, `TeamBacklog.dc.html`)** — one PO-ranked list in Jira-style sections: current Sprint (goal + flag counters) → upcoming Sprints → Backlog. Move via ⋯ or drag. Plan sprint entry point. Rank is the priority for every item type.

**13.13 Sprint planning (5p, `TeamIterationPlan.dc.html`)** — full spec in the sprint-planning decisions doc, with these latest changes:
- Header: Team calendar link, + Work item, Start sprint (ink on amber). Sprint goal card.
- Row 2 (2/3 + 1/3): **Team calendar preview** (red milestone / orange ceremony date headers) and **Team capacity card** (Plan view dropdown in the card header; Dev capacity · Velocity (✎ override, ↺ reset) · Forecast in one row; gauge up to 260 px with Commitment / Category / Category vs PI plan views).
- Sticky **Team strip**: portrait load rings (SP in Owner model, hours in Distributed model), planning style as an info pill.
- Workspace 50/50: **Backlog** (grouped by upcoming PI Sprints, then unscheduled) » **Sprint backlog** with tabs **Items · Buffer · Overhead**. Items: carry-overs first, flags, task count, owner (avatar stack in Distributed), commit icon (green ✓ / yellow ~ stretch). Clicking a title opens the **work item modal** (the old side panel is gone). Buffer and overhead tickets keep their own small detail panels.

**13.14 Team calendar (3b / 3c / 3d, `LeaveCalendar*.dc.html`)** — see §10 above.

**13.15 Work item — page (5w, `WorkItem.dc.html`) and modal (5w-m, `WorkItemModal.dc.html`)** — full spec in the work-item view doc. One layout, two containers; the modal is what the card's expand button opens. One white card; header with ID eyebrow + title, State · Owner · Size · Sprint · Commitment · Flags, tags; Details / History tabs; user story (3 lines; edit as fields), description, **AC · DoR · DoD tabs with three-state items**, tasks with a composer, discussion; right column Planning, Commitment trail, Dependencies, Status. Close story / Reopen; Remove… with reason; Delete only for mistakes. All dropdowns are custom pickers.

**13.16 Work item layout variants** — derived from type + category:
- **Bug (5w-b, `WorkItemBug.dc.html`):** Severity in the status strip; Environment (Environment / Version / Device / OS) → Steps to reproduce → Expected | Actual → Description; DoR · DoD tabs (no AC); Close bug.
- **Light story (5w-l, `WorkItemLite.dc.html`)** for Enabler / Estimation / Tech debt: Description → AC · DoD (no statement, no DoR); "Close enabler / estimation / tech debt".
- Modal versions of both are the same scale-down as 5w-m (not mocked).

### §14 Design system — additions
- **Flags & icons in rows:** missed target = red hexagon with white flag + date; aging = clock hexagon (amber ≥ 3 d with ink hands / red ≥ 5 d with white hands); blocked = red hexagon with white bar; **plan check = Kumiko warning (solid orange `#E07F24` triangle with ink "!")**, reserved for plan checks — earlier docs that say "amber triangle" mean this glyph. Order after the title: missed → aging → blocked → plan check; flags never shrink, the title truncates.
- **Commit icons:** committed = green hexagon with white ✓; stretch = yellow `#F2C230` hexagon with ink ~ (one shared glyph everywhere); buffer = dashed grey hexagon.
- **Carry-over row:** light amber tint `#FBF1DF`. **Buffers:** hatched bar in the category colour.
- **Milestone date:** solid red `#FF0000`, white text.
- **Severity swatches** (2 px-radius squares, distinct from round state dots): S1 `#D9443A`, S2 `#E8890C`, S3 `#E9C46A`, S4 `#A9ACB4`.
- **Expected / Actual result:** green / red 3 px left bars.
- **Tabs:** underline style (amber active, bold) for page/section tabs; segmented ink pill for panel views (Sprint backlog tabs).
- **Pickers:** custom picker panels instead of native selects (36 px rows, orange tint + ✓ on current, one open at a time).
- **Icon buttons:** 40 × 40 tiles, 20 px icons; only the primary action carries a label.
- **Three-state checkbox:** empty (not done) / green ✓ (done) / grey dash + struck text + "N/A".
- **Add rows** appear only after clicking an orange "+ Add …" link.
- **Small controls** (chevrons, ✓, ✕, +) use butt caps and mitred joins like the icon set — no rounded line ends anywhere.

### §14.4 Shell — navigation (replaces the handoff's menu list)
Logo menu groups, in this order:

| Group | Items |
|---|---|
| **PI** | Team PI board · ART program board · Team PI brief |
| **Capacity** | Team calendar · Capacity planner |
| **Sprint** | Team backlog · Sprint planning · Iteration board |
| **Insights** | Team dashboard |

- The current page is highlighted (orange tint, bold, dark-orange icon). The 3- and 4-week calendar boards highlight Team calendar; **work item pages and Settings highlight nothing** (they aren't menu destinations).
- **Settings lives in the profile menu**, not the logo menu.
- Menu, search and profile-menu icons are Kumiko icons at 18 px (search 16 px): grey `#67635C` by default, `#A65307` when active.

### §15 Icon set (replaces "not yet applied")
- **Applied on every screen** — the known quirk "icons not yet used in the screens" is resolved. No generic or rounded-cap glyphs remain outside charts.
- The set is now **42 icons** (`icons/icons.json` + `icons/svg/`, board 8 · Icon set), in four groups:
  - **Navigation:** team-board, art-board, pi-brief, capacity, **backlog** (new), **sprint-plan** (new), iteration, dashboard, settings.
  - **Actions:** search, add, filter, export, present, refresh, chevron, expand, **copy-link**, **more**, **edit**, **close-item** (hexagon ✓ on Close story / bug), **check** (picker selection), **close** (✕) — new where bold.
  - **Planning and capacity:** dependency, delivery-flow, objective, risk, warning (plan check), velocity, calendar, **info** (hexagon i), **lock** (new).
  - **Flags and commitment** (new section; solid badges in fixed colours, never `currentColor`): flag-missed, flag-aging, flag-blocked, commit-committed, commit-stretch, commit-buffer.
  - Plus location, clock, members and the asanoha mark.
- Rules unchanged: 24 px grid, 1.75 px line, mitred joins, butt caps, one orange cut. Line icons follow `currentColor`; badges don't.
- Remaining quirk: delivery-flow's white divider still seams on non-white backgrounds.

### §18 Proposed milestones and features — adjustments
- **M0:** add Team calendar (dated ceremonies, meetings, milestones, overtime, Days off / Dev hours) to *002 Calendar and people*; *003 Capacity engine* adds overhead reserves, velocity override chain and both per-person load models. *001 Project setup* ships the shell with the navigation above and the 42-icon set as components (line icons + badges).
- **M1:** the work item feature delivers the **work item page + modal** in three layouts (full story, light story, bug with severity and repro fields), AC/DoR/DoD with per-kind templates, tags, tasks, dependencies, commitment trail, Removed/Close; add **Team backlog**; buffers and overhead reserves set at PI planning. Still to design for M1: the **Feature/Project management view**.
- **M2:** **Sprint planning (5p)** is its own feature (capacity card, team strip, backlog » sprint backlog, buffers, overhead tickets, planning style); Start/Close Sprint commitments and their review dialogs; Iteration board refinements (buffer draws).
- **Settings additions** (whichever feature first needs them): planning style, workday hours, DoR/DoD templates (full story / light story / bug), board quick settings mirror.

### §20 Decisions log — additions (2026-11-18 → 11-20)
- Team calendar is the single source of truth for leave; capacity derives from it; commitments snapshot totals only.
- Workday 8.0 h; no focus factor.
- Overhead = hours reserve (PI planning) + optional tickets; never SP.
- Buffers = SP placeholders, typed by category, held by a person, outside the commitment; support work = SW maintenance.
- Milestones: generic, team-level, edited on the Team calendar; red date header with precedence.
- Planning style Owner / Distributed; in Distributed the owner is still required, tasks default to the owner, Sprint backlog items must be tasked; buffers convert to hours on the ring (display only).
- Work item modal replaces 5p's side panel and is what the card's expand button opens; modal = page scaled down.
- Removed state for stories and bugs (reason required; never counts in say/do); Delete only for mistakes.
- AC / DoR / DoD are three-state checklists; DoR/DoD from team templates.
- Tags are universal across the app.
- Sprint picker sets the PI; a story may be in a PI without a Sprint or in the backlog without a PI; feature/PI mismatch is a warning.
- Work item layout derives from type + category: Feature development = full story; Enabler / Estimation / Tech debt = light story (no statement, no DoR); Bug = bug layout (no AC). Change type (Story ↔ Bug) stays.
- Bug: severity S1–S4 (set at triage); environment, version, device/OS, ordered repro steps, expected / actual result; bug workflow Triage → Investigating → Correcting → Verification → Closed.
- No priority field anywhere: backlog rank is the priority.
- Navigation regrouped into PI / Capacity / Sprint / Insights; Settings in the profile menu.
- Kumiko icons applied everywhere; the set grows to 42 including status badges; plan check uses the orange warning glyph.

### §21 Open questions — status
**Resolved:** Milestone entity exists (team-level now; train-level later) · work-item details and Sprint planning designed · overhead model · hours-per-day = 8.0 per team (per-location still open) · bug-specific fields · bug workflow · priority (= rank) · icons applied to screens.
**Still open / new:**
1. **Split story** flow for carry-overs (⋯ menu) — to mock.
2. Buffer **draw** flow on the Iteration board — to mock.
3. Stretch reason popover on the commit icon; overhead tickets in the Backlog panel; "T" days on the calendar — not yet mocked.
4. Severity on board cards (proposed: S1/S2 swatch only).
5. Modal versions of the bug and light-story layouts.
6. Start Sprint / Close Sprint review dialogs.
7. Rename the "Feature" category label app-wide (e.g. "Feature dev.") to avoid confusion with the Feature entity.
8. Sprint predictability formula (deferred to M3, as before).
9. ART program board refresh and the remaining Settings sections (deferred by the operator).
10. Handoff §21 items not listed above remain open.

### §22 Prototype package — 2026-11-20 rebuild
`azusa-handoff.zip` now contains all 18 boards' sources (`prototype/*.dc.html` + `canvas.json`), fresh screenshots of every board (`screenshots/01…15`), the 42-icon set (`icons/icons.json` + SVGs), and `docs/` with data model **v0.6** and the two decision docs. New sources since the base: `TeamBacklog.dc.html` (5b) · `TeamIterationPlan.dc.html` (5p) · `LeaveCalendar.dc.html`, `LeaveCalendar3w.dc.html`, `LeaveCalendar4w.dc.html` (3b–3d) · `WorkItem.dc.html` (5w) · `WorkItemModal.dc.html` (5w-m) · `WorkItemBug.dc.html` (5w-b) · `WorkItemLite.dc.html` (5w-l). See `README.md` for the board → file → screenshot map.

---

## 2. Future enhancements (not in the current plan)
- **Queries (ADO-style):** saved filters (field · operator · value, one level of And/Or), column picker, macros (@Me, @Today, @CurrentSprint, @CurrentPI), stored as a typed JSON tree compiled to SQL via a field registry; later tree/link queries, board filters and dashboard widgets. **Search** covers finding items for now. No data-model change needed.
- Self-service days off; per-location hours/day; bug/maintenance metrics (now with severity and environment).
