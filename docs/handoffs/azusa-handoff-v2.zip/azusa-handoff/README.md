# Azusa handoff package (2026-11-20)

Design handoff from Claude to ChatGPT for (re)assessing and writing Azusa's feature briefs. **Development has not started.**

**Read in this order:**
1. `AZUSA_HANDOFF.md` — the base handoff (revised 2026-11-08, prototype refinements 2026-11-09): vision, scope, stack, design system, sample data, decisions.
2. `AZUSA_HANDOFF_UPDATE_2026-11-20.md` — everything settled since, written as deltas against the base. **Where it differs from the base, the update wins.**
3. `docs/` — the canonical detail the update points to:
   - `azusa-data-model.md` **v0.6** (supersedes the base §7, §8 formulas and §11; replaces v0.4)
   - `azusa-sprint-planning-decisions.md` (Team calendar, capacity, overhead, buffers, milestones, Distributed model, Sprint planning)
   - `azusa-work-item-view.md` (work item page / modal; story, light-story and bug layouts; severity; checklists; Removed)

The prototype is a **jumping board**. Each screen will be refined in its own feature. Where the prototype and the docs disagree, the docs win. Deferred by the operator for now: the ART program board refresh and the remaining Settings sections.

| Path | What it is |
|---|---|
| `AZUSA_HANDOFF.md` | Base handoff |
| `AZUSA_HANDOFF_UPDATE_2026-11-20.md` | Deltas since the base (wins on conflict) |
| `docs/*.md` | Data model v0.6 and the two decision docs |
| `screenshots/*.png` | Renders of every board at 1440 px wide (card sheet 2040 px). **Look here for visuals** |
| `prototype/*.dc.html` | Screen source from the Claude design canvas: markup with `{{holes}}`, `<sc-for>` / `<sc-if>`, and a `renderVals()` script holding the sample data. Needs the canvas runtime (`support.js`, not included), so read it as source |
| `prototype/canvas.json` | Board layout and titles on the design canvas ("Azusa — Wireframes") |
| `icons/icons.json`, `icons/svg/` | The "Kumiko line" icon set, **42 icons**: 24 px grid, 1.75 line, mitred, `currentColor` plus one orange `#E07F24` cut; status badges use fixed colours |
| `assets/azusa-logo*.png` | Logo. In the prototype it is referenced as `/_blob/eb2c6d73f86feb942c6986c10c979040` |

## Screens

| Board | Screen | Source | Screenshot |
|---|---|---|---|
| 1 | Team PI board (Project × Iteration) | `Main.dc.html` | `01-team-pi-board.png`, `01b-nav-menu-open.png` |
| 2 | ART program board (deferred refresh) | `ProgramBoard.dc.html` | `02-art-program-board.png` |
| 3 | Capacity planner (PI level) | `Capacity.dc.html` | `03-capacity-planner.png` |
| 4 | Team PI brief | `PIBrief.dc.html` | `04-team-pi-brief.png` |
| 5 | Iteration board (Sprint 2706) | `TeamIteration.dc.html` | `05-iteration-board.png` |
| 6 | Team dashboard | `Dashboard.dc.html` | `06-team-dashboard.png` |
| 7 | Settings › Locations and holidays (other sections deferred) | `Settings.dc.html` | `07-settings-locations-holidays.png` |
| 8 | Icon set · Kumiko line (42 icons) | `Icons.dc.html` | `08-icon-set.png` |
| — | Work-item cards at 2× (PI boards) | `Card.dc.html` | `09-work-item-cards.png` |
| 3b / 3c / 3d | Team calendar, 2- / 3- / 4-week Sprint | `LeaveCalendar.dc.html`, `LeaveCalendar3w.dc.html`, `LeaveCalendar4w.dc.html` | `10-…`, `10b-…`, `10c-team-calendar-*.png` |
| 5b | Team backlog | `TeamBacklog.dc.html` | `11-team-backlog.png` |
| 5p | Sprint planning (Distributed model demo) | `TeamIterationPlan.dc.html` | `12-sprint-planning.png` |
| 5w / 5w-m | Work item — story page and modal | `WorkItem.dc.html`, `WorkItemModal.dc.html` | `13-work-item-story-page.png`, `13b-work-item-modal.png` |
| 5w-b | Work item — bug | `WorkItemBug.dc.html` | `14-work-item-bug.png` |
| 5w-l | Work item — enabler / estimation / tech debt | `WorkItemLite.dc.html` | `15-work-item-light.png` |

Screenshots were rendered on 2026-11-20 at a 1440 × 900 viewport (full-page captures), so the header clock shows that date. The sample data is set in PI-2027.1, Sprint 2706 (Feb 2027).
