# Azusa — Design Handoff for Feature Briefs (revised)

**From:** Claude (original design and architecture) · **Updated with:** operator/ChatGPT requirement clarifications · **Date:** 2026-11-08 · **Prototype refinements:** 2026-11-09 (§13.1, §13.11, §14.4, §20)
**Package:** `azusa-handoff.zip` (hi-fi prototype source, screenshots, icon set, logo, data-model doc). This file is the single source of truth for everything discussed so far.

> **How to treat the prototype.** It is a *jumping board*, not a spec to copy pixel-for-pixel. Every screen will be re-specified and refined inside its own feature (specify → plan → tasks). Use it for layout intent, visual language, terminology and sample numbers. Where this document and the prototype disagree, this document wins. **The operator-approved decisions in the revision note below supersede any remaining contradictory legacy wording or prototype sample data.**

> **Not in the prototype yet, but required (rev 2026-11-08):**
> 1. **Freehand PI boards** (§13.9). Dependency lines are now drawn on the Team PI board (§13.1), but dragging cards and drawing new lines are not.
> 2. **Stretch stories** span several sprints, with their points split per sprint and allocated from PI Planning (§7.4, §12, §13.9).
> 3. **Days at PI level, hours at Sprint Planning** (§8.1).
> 4. **Three commitment/actual levels** recorded for planning quantities: **PI Commitment → Sprint Commitment → Actuals**, separate from manually saved Plan Versions (§11).
>
> Also: dashboards are built in and Power BI-like (§12.1).

> **Operator clarification — 2026-11-08 (authoritative).** The operator resolved the architecture review. Key corrections: (1) configurable ART cadence, custom Sprint dates/names and an optional one-**working**-day team offset; (2) explicit single-team Feature ownership, project-parented Stories and Bugs, separate Bug work-item type, non-story overhead activities; (3) directed predecessor → successor links across any project/team, plus separate external-dependency records; (4) no Features, Stories or stretch slices crossing PI boundaries; (5) PI Objective and Story commitments independent; (6) **plan versions** are complete plan snapshots and are **not** PI/Sprint commitments; (7) **Start PI** (Admin/RTE) records PI Commitments, **Start Sprint** (SM) records Sprint Commitment, **Close Sprint** (SM) finalizes Actuals; (8) retroactive Sprint start/close records selected effective date and action timestamp separately from scheduled Sprint dates, with a review of current Sprint Plan before Start Sprint. See §§7, 10–11, 13 and 20. **No additional architecture questions are blocking.**


---

## Table of contents

1. Vision
2. Project context and constraints
3. Way of working (SDD and the agent roles)
4. Scope and non-goals
5. The eight core wants, and how the design answers each
6. Glossary
7. Domain model
8. Capacity model
9. Work categories and allocation
10. Calendar: PIs, sprints, locations, holidays, absences
11. Plan versions, commitments, execution history and lifecycle
12. Metrics and thresholds
13. Screens (per-screen spec)
14. Design system
15. Icon set ("Kumiko line")
16. Technology stack and architecture
17. Lessons from the predecessor spreadsheet
18. Proposed milestones and features
19. Sample dataset used in the prototype
20. Decisions log
21. Assumptions, open questions and known gaps
22. Prototype package: contents and how to read it
23. Guidance for writing the feature briefs

---

## 1. Vision

**Azusa is a team- and ART-level Agile/SAFe planning tool built for the Scrum Master.** It is an alternative to JIRA and Azure DevOps (ADO) for teams running SAFe. The SM has used both tools extensively and finds them lacking in the places that matter most during PI Planning and sprint execution.

The pain points Azusa exists to fix:

- **Program boards stop at features.** JIRA and ADO program boards (and Miro boards) show milestones, features and feature-level dependencies, with each feature pinned to the sprint it finishes in. Azusa extends the board **down to story level**: story-to-story dependencies, the **delivery flow** inside a feature (which stories must land in which order for the feature's business value to arrive), and feature bars that **span every sprint where work happens**.
- **Capacity is missing or raw.** JIRA has none. ADO has some, but it is crude. Azusa computes capacity per member per sprint from declared days off, **per-location public holidays** and overhead deductions. Combined with **normalized velocity (SP per dev day)**, it forecasts how many story points the team can commit, and shows **load hints** directly on the boards.
- **Work categories with prescribed allocation.** Organisations split development capacity across categories (Dyson used Features, Bugs/SW maintenance, Enablers, Estimations, Tech debt). Azusa makes categories configurable, lets the train prescribe a split and lets teams override it.
- **Metrics live in spreadsheets and a home-made Power BI report.** Planned vs actual capacity, velocity, normalized velocity, throughput, sprint and PI predictability, and flow efficiency are computed from the same data that drives planning. They are shown on Azusa's **own built-in team and train dashboards, which should feel like Power BI** (slicers, cross-filtering, drill-down; see §12.1). **Azusa does not use, integrate with or export to Power BI** or any other external BI tool.
- **The team PI brief is hand-made.** At Dyson each team presented a single page at PI Planning: objectives, committed features, the capacity calculation, dependencies, risks and the confidence vote. Azusa generates that page from the plan.

**Primary user:** the SM (the project owner himself). Data entry, such as days off, is done by the SM for now. The model supports self-service by team members later.

**Predecessor:** `PI_Planner_v3.2.xlsx`, an unfinished Excel planner (the original lived on a Dyson laptop). Azusa replaces it. Its lessons are in §17.

**Personality of the product:** visual and colour-rich (the SM codes categories, features and states by colour), calm, uncluttered, Japanese-woodworking inspired (asanoha/kumiko lattice), black, white and orange on a warm light background.

---

## 2. Project context and constraints

- **A personal learning project** in the "Coding Projects" portfolio. It is *not* a startup or product. Do not frame briefs around monetisation, market fit or growth.
- **Goals:** learn by building, practise good architecture and maintainable code, and end up with a tool the SM enjoys using.
- **Standalone and local-only, like the sibling project Alice.** No deployment, no hosted services and no paid APIs. Prefer free, local and open-source options.
- **Single user now.** Multi-user and RBAC are designed into the model from day one but enforced later.
- **Privacy matters.** Absence data is minimal: the type and date of an absence, with sick-leave reasons optional and visible to the SM only. Nothing leaves the machine.
- **Long-lived.** Decisions should hold up over months. Build on prior decisions instead of re-litigating them.
- **Conventions are shared with sibling projects, but code is not.** Follow the same SDD/milestone conventions.

---

## 3. Way of working (SDD with milestones and features)

Spec-driven development, organised as milestones that contain numbered features (001, 002 …). Three agents plus the operator take part.

| Step | Owner |
|---|---|
| Overall design, architecture and the data model | **Claude** |
| Feature briefs (one per feature, from this handoff) | **ChatGPT** |
| Specify → Plan → Tasks per feature | **Agy** |
| Architecture point-of-view review of spec/plan | **Claude** |
| Developer point-of-view review of spec/plan | **Codex** |
| Implementation | **Codex** |
| Conformance review (code vs spec/design) | **Claude** |
| UAT per feature | **Claude Code + the operator (SM)**, shared |

---

## 4. Scope and non-goals

**In scope:** team level and ART (Agile Release Train) level.

**Out of scope for now:** Portfolio Kanban, Lean Portfolio Management, Strategic Themes, Large Solution/Solution Train, and any portfolio layer. The design may scale up later if there is demand.

**Hierarchy (planning work):** `Project → [Feature/Epic optional] → Story → Task`; Bugs are a **separate work-item type**, also under a Project. Non-story overhead/activity records sit outside this work hierarchy.

- A **Project** is long-lived. It can outlive a PI and has no PI dates. One or many Teams can work on it; participating Teams are **derived** from ownership of its Features, Stories and Bugs.
- A **Feature** belongs to exactly **one Team**, one Project, and one PI. Every Story under the Feature must belong to the **same Team**; work legitimately owned by another Team should be broken into its own Feature/Stories with cross-team dependencies. "Feature" and "Epic" are a **display label** (a setting), not two item types.
- A **Story** belongs to one Project and one Team. The Feature parent is optional; if present, its Team and Project must match the Story. A committed Story sits in one Sprint; a **stretch** may span several Sprints **within the same PI**, with points split across them (§7.4).
- A **Bug** has a Project and Team, is a different work-item type from Story, and may be allocated **only to the Bugs work category** (the prototype's "SW maintenance" label is sample terminology, not a requirement to conflate type and category).
- **Training, Retrospectives and General Work** are **non-story capacity/activity records** without Project parents. These are capacity deductions, not point-bearing Stories.
- **A Feature, Story or stretch StorySlice cannot cross PI boundaries.**
- **Tasks** are created at Sprint Planning. They are never planned on the PI boards; they roll up onto their parent work-item card.

---

## 5. The eight core wants, and how the design answers each

| # | Want (SM's words, condensed) | Design answer |
|---|---|---|
| 1 | Team + ART only, no portfolio | Scope in §4 |
| 2 | Extend the program board to story level: story-level dependencies and delivery flow; feature spans across the iterations where work happens | ART program board (Team × Iteration) with **derived** feature spans; Team PI board (Project × Iteration) with stories coloured by feature; dependencies stored **story-to-story**; dependency lines and out-of-order plan checks (§13.1, §13.2) |
| 3 | A refined iteration board | Kanban by workflow state, with WIP limits, category and feature chips, task roll-ups, blocked flags, burn-up (§13.5) |
| 4 | A team-level PI brief: objectives, features, capacity, dependencies, risks, confidence vote on one page | Team PI brief (§13.4) |
| 5 | Capacity from declared days off; with velocity, load hints during planning | Capacity planner and engine (§8, §13.3); load pills and bars on boards |
| 6 | Categories with prescribed allocation after General Work and Training are deducted | Configurable categories with kinds `development` and `overhead`; train defaults with team override (§9) |
| 7 | Metrics: planned vs actual capacity, velocity, normalized velocity, throughput, sprint and PI predictability, flow efficiency; bug metrics later | Metrics engine (§12) |
| 8 | Dashboards per team and per train | Team dashboard (§13.6); train dashboard still to design |

Two later additions from the SM shaped the model: **Projects** above features, and **per-location holidays** for distributed teams (an experience from Chevron).

---

## 6. Glossary

| Term | Meaning in Azusa |
|---|---|
| ART / Train | Agile Release Train: a team of teams sharing a PI cadence |
| PI | Program Increment. A fixed set of iterations, e.g. `PI-2027.1` |
| Iteration / Sprint | Admin/RTE-configured timebox of variable duration, with an editable name; `YYWW` is an optional convention representing the ISO week in which it **ends** (e.g. `2706`) |
| Stretch / slice | A **stretch** Story may span multiple Sprints **within one PI**; each Sprint holds a slice with its share of the points (5 SP = 2 + 3) |
| Plan levels | **PI Commitment → Sprint Commitment → Actuals**, preserving what was committed on Start PI/Start Sprint and finalized on Close Sprint; user-made Plan Versions are separate (§11) |
| IP sprint | Innovation and Planning sprint. The **last** sprint of the PI (`xx10` in the sample). Planned like any other sprint |
| SP | Story points |
| Dev days | Development days left after holidays, absences and overhead deductions, scaled by FTE |
| Normalized velocity (NV) | SP completed ÷ actual dev days, as a 4-sprint rolling ratio of sums. Unit: SP/day |
| Forecast SP | Team dev days × NV. The suggested commitment |
| Load | Planned SP ÷ forecast SP, as a percentage |
| Category | A type of work with an allocation %: development kinds (Feature, SW maintenance, Enabler, Estimation, Tech debt…) or overhead kinds (General Work, Training) |
| General Work (GW) | Overhead: scrum events, meetings, admin |
| Training (Tr / SI) | Overhead: training time |
| Designation | Committed / Stretch / Unplanned (Story-level; separate from whether a PI Objective is committed) |
| Delivery flow | The order in which a feature's stories must be done for its business value to arrive |
| Dependency | Directed predecessor → successor work link; A → B means **A must finish before B may start**, including across Features/Projects/Teams |
| Plan version | User-created full snapshot of a revised PI plan (v1, v2, v3…), independent of commitments |
| PI Commitment | Official planning reference established when Admin/RTE uses **Start PI**; covers each participating Team’s then-current PI Plan |
| Sprint Commitment | Official planning reference established when SM uses **Start Sprint** for a Team |
| Actuals | Execution results tracked during the Sprint and confirmed/finalized on **Close Sprint** |
| BV | Business value (planned and actual) on PI objectives |
| ROAM | Resolved / Owned / Accepted / Mitigated, plus `Not ROAMed` for risks |
| FTE factor | Capacity multiplier per member (1.0, or 0.5 for a part-timer or new joiner) |
| CW | Calendar week (ISO). The today widget shows `CW45.7` = week 45, day 7 |

---

## 7. Domain model

Canonical conceptual copy: `docs/azusa-data-model.md` (**v0.4**), included in the package. This handoff and the model were updated together after the 2026-11-08 operator review.

### 7.1 Organisation and people

| Entity | Key fields | Notes |
|---|---|---|
| **Train (ART)** | name, default categories | |
| **Team** | train, name, hours_per_day (default **8**), deduction_mode (`percent` \| `fixed_days`), deduction values, sprint_offset_workdays (−1/0/+1) | ART cadence is shared; a Team may lead/lag up to one **working day** for ceremonies and operational scheduling |
| **Member** | team, full_name, nickname, initials, role, fte_factor (default 1.0), **location**, avatar colour | Unlimited records, replacing the sheet's 13 fixed slots. `fte_factor` < 1 for part-timers and new joiners. Members with role **PO or SM never count toward capacity** |
| **User / Role** | Admin, RTE, SM, Team member, Business Owner (tentative) | Single user now, but every write records `created_by` / `updated_by` (and timestamps) |

### 7.2 Calendar

| Entity | Key fields | Notes |
|---|---|---|
| **PI** | train, name, start, end, lifecycle_status | Explicit Admin/RTE-configured boundaries; independent of calendar quarters. **Start PI** records the PI Commitments for participating Teams |
| **Iteration** | PI, name, start, end, kind (`development` \| `ip`) | Admin/RTE configures Sprint count, duration, official dates and name; optional YYWW ending-week convention. Each Team’s effective cadence may be offset by at most one working day |
| **Location** | code, name, country (ISO 3166-1), subdivision (ISO 3166-2, optional), time_zone, calendar source, last_refreshed | Starting set: **PH, SG, AU-WA, IN (Karnataka), UK (England & Wales), US-TX** |
| **Holiday** | location, date, name, portion (`full` \| `half`), source (`library` \| `company` \| `manual`), confirmed (bool) | Seeded from the `date-holidays` npm library (ISC licence; ISO 3166-2 subdivisions; substitute days). Company-declared and proclaimed days are added by hand and **override** library data. Lunar/moon-sighting dates are flagged **unconfirmed (est.)** |
| **Absence** | member, date, portion (`full` \| `am` \| `pm`), type, planned (bool), status (`active` \| `cancelled`), note (optional, SM only) | Covers the sheet's leave codes |
| **AbsenceType** | name, code, colour, affects_capacity (bool) | e.g. AL annual leave, SL sick leave (unplanned), HD half day, BT business trip (`affects_capacity: false`), WFH and on-site (attendance only) |

### 7.3 Capacity

| Entity | Key fields | Notes |
|---|---|---|
| **Category** | train, name, colour, kind (`development` \| `overhead`), default_pct, order | Fully configurable; **Bugs category** supports Bug items only. Non-story overhead includes General Work, Training and Retro |
| **TeamCategoryAllocation** | team, PI, category, pct | Overrides the train default. **Unset inherits the default.** Development % must sum to 100. Fixed for the whole PI |
| **Deduction** (PI level) | member, iteration, category (overhead), days | General Work/Training/Retro etc. recorded as **non-story** capacity/activity entries. No Project; generated from the Team's deduction mode, editable |
| **CeremonyTemplate** | team, name, hours, frequency rule | Sprint-level refinement, e.g. Planning 2h, Refinement 2.5h, Review 1h, Retro 2.5h, Daily 0.5h × (days − 2), 1-on-1s |
| **UnplannedDeduction** | member(s), date, hours, category, note | Logged during the sprint, e.g. a leadership town hall: 1.5h × 8 members = 1.5 dev days |

### 7.4 Work

| Entity | Key fields | Notes |
|---|---|---|
| **Project** | train, name, colour, description | Long-lived; teams derived |
| **Feature** | project, **owning_team**, key, name, colour (pastel palette), PI, priority, target_date, effort_estimates[] | Owned by exactly one Team; Stories under it must have matching Team and Project. Its derived span stays **within the same PI**. Estimates retain revisions (EEv1, EEv2) |
| **Story** | key, **project (required)**, feature (nullable), team, category (development), PI, points (current estimate), actual_points, designation, state, assignee | **Committed** = one Sprint/one slice; **Stretch** = multiple Sprints **within one PI**, uncommitted but capacity allocated per Sprint; **Unplanned** = added after Sprint Planning. Story with Feature must share its owning Team and Project. Featureless Stories still appear in their Project swimlane. Sprint membership comes from **slices** |
| **Bug** | key, **project (required)**, team, category (**Bugs only**), PI, state, severity/priority etc. (details in work-item spec) | Separate work-item **type** from Story, with its own workflow; not merely a Story with a bug category. The existing "SW maintenance" prototype category is a sample label |
| **StorySlice** | story, iteration, points (planned share), actual_points (set at Sprint close) | One per Sprint occupied; every slice must belong to the Story's **same PI**. Committed = one slice; Stretch = multiple slices (Σ shares = Story SP). Load reads planned slice SP; velocity reads actual slice SP (§11, §12) |
| **BoardPlacement** | board_instance (view + PI + Team/ART), item (Story, Bug, Feature or external dependency), x, y | **Layout only**, scoped per board/view instance. One Feature has one Team owner; it can still have a different visual position on Team and ART boards. Coordinates never determine capacity or historical commitments |
| **Task** | parent work item, slice (optional), member, estimate_h, remaining_h, state | Planned in **hours** at Sprint Planning (§8.1); tasking for Stories/Bugs is refined in its feature. Rolls up onto parent card |
| **Dependency** | from_story, to_story, note | **Directed predecessor → successor:** `A → B` means A must be completed **before B may start**. No restriction on Team, Feature or Project. Links involving Stretch Stories apply to the **whole Story**, not a slice. Cross-team and same-feature delivery-flow presentation are derived; invalid order is warned, not blocked |
| **ExternalDependency** | description, external owner/team/department, required date/Sprint, status, linked dependent work item(s) | Standalone lightweight record for a prerequisite **outside the ART / department**, e.g. hardware test rig availability, with no fake internal Story. Can appear in a **Dependencies** swimlane and connect to dependent work |
| **Workflow / State** | per work-item type: ordered states, each typed `active` \| `waiting` \| `done`; WIP limit per state | Story flow: New → Active → Quality Check → Acceptance → Closed. Bug flow example: Triage → Investigating → Correcting → Verification → Closed, plus Not needed / Not reproducible / Transferred / On hold |

### 7.5 PI artefacts

| Entity | Key fields | Notes |
|---|---|---|
| **PIObjective** | team, PI, text, committed (bool), bv_planned, bv_actual, scored_by, linked features | Objective committed/uncommitted is **independent** of Story committed/stretch/unplanned designation |
| **Risk** | team, PI, text, roam (`unroamed` \| R \| O \| A \| M), owner | |
| **ConfidenceVote** | team or train, PI, votes[1..5] counts | |
| **Milestone** | train, PI, iteration/date, name | e.g. PCI audit, Code freeze, Release, PI demo + planning. Shown on the ART board |

### 7.6 History and lifecycle (core from day one, not an add-on)

| Entity / concept | Purpose |
|---|---|
| **PlanVersion** | Explicit v1/v2/v3… **complete snapshot of the PI planning state** (including unchanged prior-plan content), taken by a user to preserve revisions. Independent of commitments and execution history |
| **PICommitment** | Official, historically immutable reference to the participating Teams' PI Plans as reviewed when Admin/RTE executes **Start PI** |
| **SprintCommitment** | Official, historically immutable reference to the current Team Sprint Plan as reviewed when SM executes **Start Sprint**. Captures what the SM actually approves, even on a retroactive start |
| **SprintClosure / Actuals** | SM executes **Close Sprint** and confirms actual points/capacity; preserves scheduled Sprint dates, selected effective close date, and actual action timestamp |
| **Sprint lifecycle dates** | Distinguish configured **scheduled dates**, SM-selected **effective start/close dates**, and audit **recorded_at** timestamps. Late/early clicks do not rewrite the scheduled calendar |
| **StateChange** | (item, from_state, to_state, at, by). Every workflow transition with a timestamp. Feeds throughput, cycle time and flow efficiency |

Implementation may reuse a common snapshot mechanism, but **versioning and commitment are separate domain functions**. Do not call the user action “Baseline the PI” or conflate a plan version with a commitment record.

### 7.7 Derived (never stored as truth)

- Feature span = min to max iteration of its stories.
- Teams on a Project = distinct owners of its Stories, Bugs and Features.
- Cross-team dependency = a dependency whose two stories have different teams.
- Delivery-flow order = topological order of the dependencies inside a feature.
- Load = Σ **slice** SP planned in the iteration ÷ forecast SP, per team × iteration (overall and by category).
- Story span = first to last iteration of its slices.

---

## 8. Capacity model

**Units:** capacity is in **days**; commitments are in **story points**. **Normalized velocity (SP/day)** is the bridge. Raw velocity rises and falls with available days (holidays, leave, events), so it can't be compared across sprints. Normalized velocity can, and multiplying it by next sprint's dev days gives a realistic commitment.

Per member *m* (excluding PO and SM) per iteration *i*:

```
working_days(m,i)    = NETWORKDAYS(i.start, i.end, holidays(location(m)))
available_days(m,i)  = working_days(m,i) − Σ absences(m,i | affects_capacity, status=active)   (half day = 0.5)
overhead_days(m,i)   = Σ deductions(m,i)                       ← PI level, in days
                       Sprint Planning refines this to Σ ceremony/meeting hours ÷ hours_per_day,
                       plus unplanned deductions logged during the sprint
dev_days(m,i)        = fte_factor(m) × (available_days − overhead_days)

team_dev_days(i)     = Σ_m dev_days(m,i)
forecast_sp(i)       = team_dev_days(i) × normalized_velocity(team)
category_budget(c,i) = forecast_sp(i) × allocation_pct(c)
load(i)              = planned_sp(i) ÷ forecast_sp(i)
```

**Rules**

- **Deduction mode is per team:**
  - `percent` of available days (Dyson style, e.g. 20%).
  - `fixed_days` per member per iteration (Chevron: 3 days per 15-day sprint).
- At **PI level**, deductions are in days. At **Sprint Planning** they are refined in hours (ceremony template), because leadership often calls unannounced meetings.
- **Hours per day:** default 8, with a team override. Possibly per location later (UK 7.5h; see open questions).
- **PO and SM** are never counted.
- **`fte_factor`** covers part-timers and new joiners (0.5). The working-day calculation uses the Team's scheduled Sprint window when a permitted ±1 working-day stagger is configured.
- **Overhead capacity/activity entries** (General Work, Training, Retrospectives) draw on `overhead_days`. They are **not** Stories, require **no Project**, and have **no Story Points** or velocity credit; warn if the actual time consumed exceeds the planned overhead allowance.
- **Normalized velocity** = Σ completed *development* SP ÷ Σ *actual* dev days over a **4-sprint rolling window**.
  - It is a **ratio of sums**, not an average of ratios, so a short sprint doesn't distort it.
  - Until 4 sprints of history exist, use what is available, falling back to a manual seed value (the sheet's hand-typed `Ave Vel`).
- **Board hint:** each Team × iteration cell shows `planned / forecast` and load %, overall and optionally by category; for permitted Team scheduling offsets, use that Team's adjusted Sprint working days.

**Worked example (prototype sample, team Palawan, PI-2027.1, fixed-days mode GW 1 + Tr 0.5 per member per sprint, NV 0.92):**

| Sprint | Team dev days | Forecast SP |
|---|---|---|
| 2702 | 60.75 → 60.8 | 56 |
| 2704 | 55.75 → 55.8 | 51 |
| 2706 | 59.75 → 59.8 | 55 |
| 2708 | 56.25 → 56.3 | 52 |
| 2710 IP | 58.75 → 58.8 | 54 |
| **PI** | **291.25 → 291.3** | **268** (sum of per-sprint rounded values; 291.25 × 0.92 = 267.95) |

The member formula, as in the prototype: `fte × (10 − holidays − leave − 1 − 0.5)`. A full sprint with no time off is 8.5 dev days; Hana (0.5 FTE) gets 4.25.

> **Implementation note:** the engine should be a **pure TypeScript module** with **golden tests** reproducing these numbers and the spreadsheet's (Vitest). Rounding is presentation-only: compute with full precision and round at display time. Decide and document how per-sprint forecasts sum (sum of rounded vs rounded sum).

### 8.1 Units: days at PI level, hours at Sprint Planning

| Context | Unit shown | What is measured |
|---|---|---|
| PI planning, Capacity planner, boards, dashboards | **Days** | Dev days per member and team; deductions in days |
| Sprint Planning, iteration board | **Hours** | Each member's available hours = dev days × `hours_per_day`; ceremonies and meetings (CeremonyTemplate); unplanned deductions; task estimates and remaining hours |

- Sprint Planning shows **per-member hour load**: Σ task hours assigned ÷ the member's available hours, using the same 85/115 bands. This is where individual over-allocation becomes visible. PI planning stays at team level.
- **Recommendation for the engine:** store all durations in **one canonical unit (minutes, as integers)** and convert for display using the team's `hours_per_day`. This avoids float drift (e.g. 1.5 h × 8 members ÷ 8 h = 1.5 days) and keeps the days and hours views consistent. A half-day absence = ½ × `hours_per_day`.
- Story **points** stay a separate unit. They are never converted to hours; the only bridge between SP and time is normalized velocity (SP per dev day).

---

## 9. Work categories and allocation

- Categories are **configurable per train**. Not every organisation uses Dyson's five; some use only Features.
- Each category has a **kind**:
  - `development` categories share the dev capacity by %.
  - `overhead` categories (General Work, Training) are **deducted before** dev capacity is computed.
- The **train defines** the categories and default %. **Teams override the % only** (never the list).
  - An **unset override inherits** the train default (the spreadsheet wrongly treated blank as 0%).
  - Development % must **sum to 100** (the UI shows a "100% ✓" badge).
- The split is **fixed per PI** (it does not vary per iteration). The agreed split is preserved in PI Plan Versions and the PI Commitment when the PI starts.
- **Every development Story has a development category. Bugs are a separate work-item type, assigned only to the Bugs category.** The prototype's "SW maintenance" wording is a sample default that may be relabeled to Bugs; it is not permission to make Bug and Story the same type.
- **General Work, Training and Retro are time-based, non-story overhead records** that deduct capacity before development budgets are calculated. Never create point-bearing Stories simply to account for those hours; they do not contribute to velocity.

**Default categories and colours (sample train "Payments ART")**

| Category | Kind | Colour | Train default | Palawan override |
|---|---|---|---|---|
| Feature development | development | `#2E8B57` green | 49% | **56%** |
| SW maintenance (bugs) | development | `#C93A3A` red | 20% | **15%** |
| Enablers | development | `#E8890C` orange | 14% | inherit |
| Estimations | development | `#7A4CC2` purple | 10% | **8%** |
| Technical debt | development | `#3F4148` dark grey | 7% | inherit |
| General work | overhead | `#A39C93` warm grey | 1 day / member / sprint (sample) | |
| Training | overhead | `#5C7A1F` olive | 0.5 day / member / sprint (sample) | |

Palawan budget for the PI (268 SP): Feature 150, SW maintenance 40, Enablers 37, Estimations 21, Tech debt 18.

Short labels used on cards: Feature, SW maint., Enabler, Estimation, Tech debt. Keys in sample data: FD, SW, EN, ES, TD.

---

## 10. Calendar: PIs, sprints, locations, holidays, absences

### Sprints and PIs

- **An Admin/RTE configures the ART's PI structure**: number of Sprints, Sprint duration (not necessarily two weeks), named Sprints, and explicit PI/Sprint start and end dates. Different organisations/ARTs can choose different cadences.
- Teams in one ART follow the **same overall cadence and iteration identity**, but a Team may have a consistent **lead/lag of up to one working day** for Sprint ceremonies/scheduling. This accommodates one SM/PO supporting multiple Teams. More than one working day is outside the agreed normal rule. An implementation must distinguish the canonical ART iteration from Team-specific scheduled Sprint boundaries when calculating capacity and timing.
- **`YYWW` is an optional, tentative naming convention** referring to the **ISO calendar week in which the Sprint ends**. Admin/RTE can supply any Sprint name. Store names explicitly; never derive dates from names.
- The final **IP** iteration, when included, is planned like any other Sprint; the number of development iterations is configurable.
- PI names such as `PI-YYYY.n` and calendar-quarter mappings in the prototype are **examples, not mandatory rules**. A PI need not coincide with a calendar quarter.
- **A Feature, Story and Stretch StorySlice must remain within one PI**. Team offsets must be modeled without silently relaxing this ownership constraint.

**Prototype sample only** (not a fixed cadence): PI-2027.1 has development Sprints 2702, 2704, 2706, 2708 plus IP Sprint 2710:

| Sprint | Dates (2027) | Notes |
|---|---|---|
| 2702 | Jan 4–15 | |
| 2704 | Jan 18–29 | |
| 2706 | Feb 1–12 | "now" in sample |
| 2708 | Feb 15–26 | |
| 2710 · IP | Mar 1–12 | Innovation and Planning |

### Locations and holidays

- **Holidays belong to locations, not teams.** Each member has a location, and working days are computed per member. A team can be spread across many locations (the Chevron experience).
- Starting locations:

  | Code | Name | Time zone | Calendar source |
  |---|---|---|---|
  | PH | Philippines | UTC+8 | Public holidays, PH |
  | SG | Singapore | UTC+8 | Public holidays, SG |
  | AU-WA | Western Australia | UTC+8 | Public holidays, AU · WA |
  | IN | India · Karnataka | UTC+5:30 | Public holidays, IN · KA |
  | UK | United Kingdom · England | UTC+0 | Bank holidays, GB · ENG |
  | US-TX | United States · Texas | UTC−6 | Federal holidays + 1 company day |

- Seed from **`date-holidays`** (npm, ISC). Company and manual holidays override the library. A "Refresh from public calendars" action re-pulls library data and keeps manual edits.
- Holiday states shown in Settings:
  - public holiday (sand fill)
  - company holiday (orange-tinted fill with an orange outline)
  - date not yet confirmed (**dashed** border, "(est.)")
  - falls on a weekend (muted/greyed, no capacity effect)
- **Holidays are managed only in Settings › Locations and holidays** (a full-year, month × location view). Planning screens show only their **effect** (e.g. "−1 holiday" chips, "2 locations off" in sprint headers).
- Sample holidays inside PI-2027.1 that affect capacity:

  | Location | Holidays (sprint) |
  |---|---|
  | PH | EDSA Revolution Anniversary, Feb 25 (2708) |
  | SG | Chinese New Year (in lieu), Feb 8 (2706); Hari Raya Puasa (est.), Mar 10 (2710) |
  | AU-WA | Australia Day, Jan 26 (2704); Labour Day, Mar 1 (2710) |
  | IN | Republic Day, Jan 26 (2704) |
  | UK | none |
  | US-TX | Martin Luther King Jr. Day, Jan 18 (2704); Presidents' Day, Feb 15 (2708) |

### Absences

- Entered by the **SM** for now. The model supports team self-service later (RBAC).
- Types and colours used in the prototype's day grid:

  | Code | Type | Colour / style | Capacity effect |
  |---|---|---|---|
  | AL | Annual leave | `#4A7FD4` fill | Reduces capacity |
  | SL | Sick leave · unplanned | `#CC5A7A` fill | Reduces capacity |
  | HD (½) | Half day | `#A8C3EE` fill | Reduces by 0.5 |
  | BT | Business trip | `#E5E9F0` fill | No deduction |
  | HO | Public holiday · by location | Hatched sand | Reduces capacity (shown for effect only) |
  | CX | Cancelled | Dashed outline | None |

---

## 11. Workflows, plan versions, commitments and execution history

- Workflows are configured per **work-item type**: Story and Bug are distinct types, with ordered states typed **active**, **waiting** or **done**, and optional WIP limits. Categories do not substitute for types.
- Default Story workflow and colours (prototype example):

  | State | Proposed type | Colour |
  |---|---|---|
  | New | waiting | `#8A847C` |
  | Active | active | `#2F62C8` |
  | Quality Check | active | `#7A4CC2` |
  | Acceptance | waiting | `#C27A10` |
  | Closed | done | `#2E7D46` |

  Confirm the exact Acceptance type in the workflow feature, not before M0. Record **StateChange** on every transition from day one.

### 11.1 Three recorded planning levels

**PI Commitment → Sprint Commitment → Actuals** describe the official three-level performance trail; the user continues to edit one current estimate field, not three independent columns.

| Level | Domain event | What is recorded |
|---|---|---|
| **PI Commitment** | **Start PI** by Admin/RTE | The participating Teams' **current PI Plans** become official PI commitments at that point. One PI start event records the commitment references for the Teams; it is not an informal manual "baseline" operation |
| **Sprint Commitment** | **Start Sprint** by the responsible SM | The **current Team Sprint Plan**, after explicit SM review, becomes that Sprint's official commitment, including its Story/Slice allocations, capacity assumptions and relevant planning state |
| **Actuals** | Progress recorded during execution; **Close Sprint** by SM | At closure SM reviews and finalizes actual Story and stretch-slice points, actual capacity, etc. Execution history and StateChange events remain recorded throughout the Sprint |

- **PI Objective commitment is independent of Story commitment designations**. A committed business objective does not force all linked Stories to be committed.
- Preserve the historic commitments even when estimates, stories or later plans change. The latest working plan must never silently overwrite an already established commitment.
- Keep a `plan_trail` read model for PI Commitment / Sprint Commitment / Actual / Current, with comparisons at Story, slice, Feature and capacity levels.
- Example: a Story may be **3 SP in the PI Commitment, 5 SP in the Sprint Commitment, 5 SP actual**. A Story added after PI start has no PI Commitment value, rather than a fabricated zero.
- Stretch Stories may have different Sprint Commitments for their successive slices, but no Story or slice crosses its PI boundary.
- Planned vs actual, estimate drift, scope change and predictability should read the appropriate **commitment event**, never an arbitrarily selected or latest plan version. Sprint predictability's exact formula is still deferred to its feature.

**Where the user sees the trail** (operator-requested; the UI shows three values even though the user edits one field):

- **Story detail panel:** a "Plan trail" row, `PI 3 → Sprint 5 → Actual 5`, with the change highlighted (e.g. "+2" in amber). Stretches show one Sprint Commitment value per Sprint they occupy. Items added after Start PI show "—" for PI, not 0.
- **Board cards:** a small **"3→5"** drift badge when the current estimate differs from the PI Commitment, so drift is visible mid-PI without opening the card.
- **Compare to commitment / compare to version** (Team PI board): moved or resized cards show a faded ghost at their reference position, with an arrow to where they are now. The reference (PI Commitment or Plan vN) is always labelled.
- **Feature roll-up:** PI Commitment SP / Sprint Commitment SP / Actual SP per Feature, plus items added and dropped.
- **Dashboards:** estimate drift, plan stability, scope change and stretch delivery, all read from `plan_trail`.

Illustrative `plan_trail` output (shape only; not a schema):

```
item     | pi_commitment | sprint_commitment | actual | current
PAY-439  |       3       |         5         |   5    |    5
PAY-480  |       5       |         —         |   —    |    8   ← re-estimated, Sprint not started
PAY-512  |       —       |         3         |   3    |    3   ← added after Start PI
```

### 11.2 Plan versions (separate feature/concept)

**Versioning is not commitment.** A user can save **v1**, **v2**, **v3**, etc. as **complete snapshots of the current PI planning state**: v1 initial draft, v2 revised after planning presentation feedback, v3 a mid-PI replan as priorities change. Each version represents the entire plan at that point, inheriting unchanged elements from earlier versions and preserving modifications; earlier versions remain available for historical comparison.

A full planning version includes the planning-relevant current state: Projects/Features/work items, Story/Sprint assignments and stretch slices, estimates and designations, dependency links (including external), allocations and capacity assumptions, PI objectives, risks, milestones, and board layout for the relevant PI. It is **not** a replacement for separately maintained Actuals or StateChange audit history.

- Plan versions are intentionally created **independently** of Start PI and Start Sprint events. A commitment references/snapshots the current plan at the relevant event, whether the latest manually saved version is v2, v3, etc.
- No plan version may rewrite previously committed records or actual execution history.
- Internal storage may use queryable snapshot rows/shared infrastructure, but preserve domain separation between `PlanVersion`, `PICommitment`, `SprintCommitment` and `SprintClosure`. Do not infer that clicking **Start PI** creates the next manual vN.
- Compare-to-commitment and compare-to-version may share UI machinery, but they are semantically different comparisons.

### 11.3 Sprint lifecycle: scheduling, backdating and review

A Sprint has **three distinct date concepts**:

1. **Scheduled dates**: official Team Sprint start/end from ART cadence, adjusted if Team uses its allowed ±1 **working-day** offset.
2. **Effective lifecycle dates**: dates the SM selects in the **Start Sprint / Close Sprint date picker**, which may be entered retroactively or ahead of the scheduled end when ceremonies/holidays make that practical.
3. **Actual action timestamps**: when the SM clicked and confirmed the action in Azusa; audit these independently of effective dates.

The SM may start a Sprint late in the UI because of clerical workload and select the intended effective start; the same applies to closing early after an earlier Review/Retro (e.g. holidays on planned Days 9–10) or closing on Day 1 of the following Sprint. **The official scheduled Sprint end remains unchanged**; do not recalculate planned duration solely from the click date.

**Start Sprint confirmation flow**:

1. Offer an effective-date picker defaulted to the scheduled date.
2. Show the **current** Team Sprint Plan for review before commitment: Story count, committed SP, stretch slices, estimated capacity/forecast, load, dependencies and relevant plan checks/warnings.
3. SM confirms **Start Sprint**. Record exactly the **current reviewed plan**, even if the confirmation is retroactive, together with its effective date and action timestamp. Never silently reconstruct an earlier backlog or automatically force its previous values.
4. Later backlog changes may occur through legitimate team-level replanning, but must not modify the recorded Sprint Commitment.

**Operator-confirmed example**: The team planned 40 SP Monday, changed its current Sprint Plan to 48 SP Tuesday, and the SM starts the Sprint retroactively on Wednesday effective Monday. After reviewing the current plan, **48 SP is recorded as the Sprint Commitment**. Azusa trusts the SM/team; it offers warnings and transparency rather than hard-blocking or guessing what was agreed Monday. Clerical corrections are handled through review before confirmation.

**Close Sprint confirmation flow**: SM chooses the effective close date, reviews/prefilled actuals and confirms. Persist actuals plus selected effective date and action timestamp; retain scheduled Sprint end. For stretch slices confirm actual SP, with adjustments to remaining future slices visible as replanning.

### 11.4 Suggested storage/read-model principles (not a preapproved schema)

- Capture immutable **commitment records** at lifecycle events, including story/slice allocations, designations, relevant Feature/Project/Team membership, capacity assumptions/deductions, category splits and other information needed for historical calculations. Use queryable rows or appropriately normalized snapshots rather than only relying on mutable current tables.
- Keep **manually saved full plan versions** separately identified and immutable. A shared snapshot mechanism is permitted, not required.
- Keep **execution events** (StateChange and actuals) independent; `plan_trail` joins commitment snapshots and actuals for reporting.
- Model a board instance by its **view, PI and Team/ART scope**, so coordinates on Team and ART boards don't collide. Feature ownership remains single-Team.
- These are architecture requirements; exact table names and snapshot normalization remain Claude's responsibility at the planning/spec phase.

## 12. Metrics and thresholds

| Metric | Definition |
|---|---|
| Planned vs actual capacity | PI/Sprint **Commitment** capacity vs finalized actual (after real absences and unplanned deductions), with the matching planning level clearly identified |
| Velocity | **Actual** SP of **development** work done in the iteration: point-bearing Stories reaching Done (their actual points) plus confirmed stretch-slice actual SP. Bug counting/point conventions should be specified explicitly with the new distinct Bug work-item type; do not silently omit Bugs |
| Normalized velocity | Velocity ÷ actual dev days. 4-sprint rolling ratio of sums |
| Throughput | Count of items reaching Done per iteration (by type/category) |
| Sprint predictability (commitment accuracy) | **Placeholder:** done committed SP ÷ committed SP at the **Sprint Commitment**. **The SM will supply the actual formula when the dashboard work starts. Do not finalize it in any brief before then.** |
| PI predictability | Σ actual BV ÷ Σ planned BV of **committed** objectives. Stretch (uncommitted) objectives count in the numerator only, per SAFe |
| Flow efficiency | Time in `active` states ÷ total cycle time |
| Later | Bug/maintenance metrics: MTTR, reopen rate, ageing by bug state |

**Committed vs stretch in the metrics**

- **Load** counts planned slice points of **all** designations, including stretch allocations. Stretch work consumes capacity even though it is not committed.
- **Sprint predictability** (placeholder until the SM's formula arrives) counts **committed** Stories only, using the **Sprint Commitment** as reference; re-estimating at Done cannot silently revise that reference.
- **Velocity and normalized velocity** use **actual** points, including the actual stretch-slice points recorded at sprint close (§11.1). This keeps velocity smooth when stretches run across sprints.
- **Throughput** counts each story once, when it closes.
- If a stretch's actual slice points fall short, the remainder moves to its next slice (a re-plan, visible in the next plan-version and/or commitment comparison).

**Thresholds (configurable; defaults are the SM's rule of thumb):**

- Predictability gauges and load: **< 85% amber · 85–115% green · > 115% red**. Over-delivery signals under-commitment.
- The old spreadsheet used < 85% Failed, ≥ 85% Passed, 100% Success.
- Flow-efficiency gauge bands: < 15% red · 15–30% amber · ≥ 30% green. These are the prototype's bands; confirm them.
- Gauge scale for predictability: 0–130%, with ticks at 85, 100 and 115.

**One engine, two levels.** Team and train dashboards read the same metric definitions, so they can never disagree. Every number should link to its definition and the stories behind it (the dashboard subtitle says so).

### 12.1 Reporting experience: Power BI-like, built in

The SM wants **Power BI-style dashboards and reporting inside Azusa**. Power BI itself is **not** part of the solution: no connector, no `.pbix`, no dataset export aimed at it. "Power BI-like" means these interactions:

- **Slicers:** page-level filters for team, train, PI, sprint range, category and project/feature. They apply to every visual on the page and persist in the URL, so a view can be bookmarked.
- **Cross-filtering:** clicking a visual element filters the others. For example, clicking the "SW maintenance" donut segment filters the velocity, throughput and capacity charts to that category; clicking a sprint bar focuses that sprint.
- **Drill-down:** train → team → sprint → stories, and PI → sprint.
- **Drill-through:** any number opens the list of stories or state changes behind it, together with the metric's definition.
- **Rich tooltips:** exact values, plus the formula inputs (e.g. "53 SP committed, 50 done → 94%").
- **Comparisons:** vs the previous Sprint/PI, vs the relevant **PI/Sprint Commitment** or chosen **Plan Version**, and vs the target/allocation, with deltas shown.
- **Export:** PNG/PDF of a dashboard, and CSV of the data behind any visual.

**Default scope:** **curated** dashboards (team and train) with the interactions above. A **user-built report designer** (drag fields onto a canvas to make new visuals) is **out of scope** unless the SM asks for it (see §21).

Implications for the build:
- The metrics engine must return **queryable facts** (per story, per sprint, per category), not just final numbers, so visuals can filter each other.
- The chart spike (feature 005) must prove that cross-filtering and drill-through work with the chosen library.

---

## 13. Screens (per-screen spec)

All screens share the shell in §14.4. Screenshots are in `screenshots/`. Sample team: **Palawan**; PI **PI-2027.1**; current sprint **2706**.

### 13.1 Team PI board (`Main.dc.html`, screenshot 01)

**Purpose:** team-level PI planning. **Rows = Projects** (this team's), **columns = Iterations**. This matches how the team used Miro at Dyson: free-form, iterations as columns, projects as swimlanes, stories colour-coded by feature.

- **Viewport:** designed for the **1440 × 900 baseline** (§14.4). The board is far wider than the page (2,844px at 100%), so it opens at **Fit** (about 49%).
- **Title row:**
  - Left: "Team PI board" and a **plan version chip** (orange pill, ink text, e.g. **v2**). There is no subtitle.
  - Right: the **plan issues** button (only when issues exist), the **Lines** dropdown, **Filters**, **Legend**, **Compare versions** and the primary **+ Story**.
  - The UI must still distinguish **Plan vN** from **PI Commitment**, and allow **Compare to commitment / chosen plan version** (§11).
- **Plan issues button:** the Kumiko warning icon (24px) and the issue count only, e.g. "⚠ 3". It opens the **Plan checks modal**:
  - **Order** (red): a story planned before a predecessor it depends on.
  - **Cross-team** (red): a predecessor from another Team/Project (or an external prerequisite) lands after its successor needs it.
  - **Load** (amber): e.g. IP at 70%, below the 85% band.
  - **Split** (green, passing): category split within 3 pts of the team allocation.
  - Footer: "Checks are advisory. They never block Start PI or Start Sprint."
- **Lines dropdown** (labelled "Lines"): **All** (every dependency), **Highlighted** (only lines touching highlighted features), **None**. The prototype defaults to All.
- **Filters button** toggles a **filter bar** under the title row; the button shows a selected state (`#FCEFE2` background, `#A65307` text) while open. The bar is transparent with white controls:
  - **Team** (mock options: Palawan, Siargao, Bohol, Cebu, with focus and FTE), **PI** (closed / in progress / planning PIs with status) and **View** (*Stories*: every story and bug as its own card; *Features*: one card per feature spanning its sprints).
  - **Highlight**: a **multi-select** feature dropdown with swatches and a "Clear" action. Highlighting dims every non-highlighted card to 35%. It replaces the old radio-style Feature focus bar.
  - Dropdowns have **fixed widths** (170 / 170 / 160 / 270px) and are 36px high, so the controls never shift when the value changes.
- **Legend button** toggles a **legend bar** (white, two tight rows): *Categories* (the left-bar colours) and *Lines* (same feature = solid in the feature colour; cross-team = dashed ink; late = red). When Filters and Legend are both open, the filter bar sits above the legend bar.
- **Column headers:** sprint name, dates, notes (e.g. "2 locations off"), a **load bar** and `planned / forecast SP` with a % (e.g. 2706 = 58/55 SP 105%), coloured by the load bands. The current sprint is tagged **NOW** and its column is tinted (`#FFFBF6`).
- **Swimlanes:** Saved Payments, Checkout Revamp and Platform Hygiene (no feature: bugs, debt, estimates). The lane name is **rotated** (vertical) and centred in a **44px** label column, so the board spends its width on sprints. There is no lane meta text.
- **Board geometry (prototype):** 5 sprint columns of **560px**, so **two card columns fit per sprint** with a 40px horizontal gap. Cards are placed freehand (small x/y jitter in the sample) and lanes grow to fit their cards. The board and cards are white.
- **Zoom:** a floating control (bottom right) with − / % / + / **Fit**. Steps are 50%, 75%, 100% and 125%. Fit scales the board to the page width. When zoomed in, the board scrolls sideways inside its frame.
- **Cards:** see §13.11 for the full card spec. Warning cards get a 2px red (`#EF1F2C`) outline.
- **Dependency lines:** drawn between the cards' **8 anchor points** (§13.11), with arrowheads. The router picks the closest pair of anchors that face each other and avoids reusing an anchor. Styles follow the legend. Lines touching dimmed cards fade.
- **Removed from the earlier prototype:** page subtitles, the Feature focus bar, the delivery-flow strip and the bottom plan-checks panel. Delivery-flow ordering lives on as the **Order** check and the line styles.
- **Tasks:** not shown at PI planning. After Sprint Planning they roll up onto the card ("3/5 tasks · 14h left").

### 13.2 ART program board (`ProgramBoard.dc.html`, screenshot 02)

**Purpose:** ART-level PI planning and overview. **Rows = Teams**, **columns = Iterations**.

- **Title row:** Train dropdown (Payments ART), PI dropdown, and a toggle for **Features / Stories / Dependencies**.
- **KPI tiles:** train load 91%; dependency count (including late ones); "4 under · 0 over" band count; features done.
- **Milestone row:** PCI audit (2704), Code freeze 27.1 (2706), Release 27.1 (2708), PI demo + planning (2710). These sample Sprint identifiers and dates are not mandated for other ARTs.
- **Team rows:**
  - Name and meta (e.g. "Palawan · Checkout · 7.5 FTE · 6 locations").
  - A **load pill** per sprint (e.g. "93% load"), coloured by band.
  - **Derived feature bars** that span from the first to the last sprint containing the feature's stories. Each bar shows its swatch, name, meta ("5 stories · 26 SP"), a progress fill, and a dependency chip ("1 out", "1 late"). Late bars get a red outline.
- **Dependency table:** needing team/work item → predecessor/provider (internal or external), needed Sprint, planned Sprint/date, status (Late / Same Sprint / On time). Internal edges are directed predecessor → successor; external prerequisites are dedicated records without fabricated internal Stories.
- Both boards read the same stories and links. The Stories view should allow drilling to story level (rolled up, not literally zoomed).

### 13.3 Capacity planner (`Capacity.dc.html`, screenshot 03)

- **Title row:** Team and PI dropdowns; **Deduction mode** toggle (Fixed days / % of available); Hours per day input (8). Subtitle: "8 members in 6 locations · PO and SM are not counted · holiday calendars in Settings" (a link). Primary "+ Day off".
- **KPI tiles:** Development days 291.3; Normalized velocity 0.92 SP/day ("4-sprint rolling · Σ SP ÷ Σ days"); Forecast commitment 268 SP (dark tile, "291.3 days × 0.92 SP/day"); Team FTE 7.5 ("Hana counted at 0.5 (new joiner)").
- **Member × sprint table:**
  - Member cells: avatar, name, role and FTE, a **location badge** (ink pill).
  - Day cells: dev days plus chips "−2 leave" (blue) and "−1 holiday" (sand).
  - Footer rows: deductions per member (GW 1, Tr 0.5), **Team dev days**, **Forecast SP × 0.92** (orange).
  - Sprint headers show "n locations off".
- **Category split card:** donut (268 SP at centre); table of Category / Train % / Team % (override chip, or italic "inherit") / SP; badge "100% ✓"; Overhead section ("Deducted first": General work 1 day, Training 0.5 day per member per sprint). These overhead items are non-story time deductions.
- **Days off grid** for one sprint (2706, Feb 1–12): member × day cells with AL/SL/½/BT/HO/CX markers and a legend. "Click a day to add or cancel."
- **Unplanned deductions:** e.g. "Leadership town hall, Feb 10 · 1.5 h × 8 members = 1.5 dev days deducted from actual capacity", with "+ Log another".

### 13.4 Team PI brief (`PIBrief.dc.html`, screenshot 04)

**The Dyson one-pager**, generated from the plan. It must be presentable and exportable.

- **Controls row** (right-aligned, above the hero): Team, PI, Export PDF, Present.
- **Dark hero** with the asanoha pattern: team and PI, committed BV 31, 242 / 268 SP planned vs forecast, confidence 3.9.
- **PI objectives:**
  - Committed: Shoppers can pay with a saved card (F-112, BV 10); One-page checkout live for 25% of traffic (F-119, BV 8); Address autofill in production (F-118, BV 7); Card updater keeps saved cards valid (F-125, BV 6).
  - Uncommitted (dashed pill): Wallet pay in internal beta (F-121, BV 5); Cut the checkout bug backlog by 30% (no feature, BV 4).
- **Features** with SP and a 5-cell sprint span: F-112 26 SP 2702–2708; F-119 32 SP 2704–2710; F-125 18 SP 2706–2710; F-118 19 SP 2702–2704; F-121 13 SP 2708–2710.
- **Capacity per sprint:** dev days / forecast / planned / % bar. Dev days 60.8, 55.8, 59.8, 56.3, 58.8; forecast 56, 51, 55, 52, 54; planned 52, 50, 58, 44, 38.
- **Dependencies in/out:**
  - In: Siargao, Tokenization API v2 for PAY-421 (Delivered); Bohol, Merchant certificates for PAY-480 (Late · 2710).
  - Out: Bohol, Inline payment step for MER-30 (On track · 2706); Cebu, Saved-card events for RSK-12 (On track · 2704).
- **Risks (ROAM):**
  - Not ROAMed (red): no 3DS sandbox access yet.
  - Owned (SM): merchant certificates from Bohol land one sprint late.
  - Mitigated (Ben): SDK v9 upgrade could break 3DS flows; feature flag + rollback.
  - Accepted (Team): 2708 has a holiday and 5 days of leave.
  - Resolved (Siargao): Tokenization API v2 might slip; delivered in 2702.
- **Confidence vote:** bars for fists 1–5, counts [0, 0, 2, 5, 1] → average 3.9. Bar colours run 1→5: `#D9443A`, `#E9A23B`, `#E9C46A`, `#E07F24`, `#1A1B22`.

### 13.5 Iteration board (`TeamIteration.dc.html`, screenshot 05)

- Sprint **2706**. Columns are the workflow states, each with a colour dot, count, SP and WIP chip:

  | Column | WIP |
  |---|---|
  | New | — |
  | Active | 3 / 4 |
  | Quality Check | 1 / 2 |
  | Acceptance | 1 / 2 |
  | Closed | — (cards at 75% opacity) |

- **Card:** key, title, SP; category chip (tinted); feature chip (swatch); a **task progress bar** with "3/5 tasks · 9h left"; assignee avatar; age ("3 days active", "Waiting for PO", "Closed Feb 3"); **BLOCKED** flag with a red outline.
- **KPI tiles:** 7 / 58 SP closed; 58.3 / 60.8 dev days (actual vs planned); a burn-up mini chart. Add **Start Sprint** and **Close Sprint** lifecycle actions with review and effective-date picker (§11.3) in the feature that implements execution.
- **Category filter chips:** All, Feature, SW maint., Enabler, Estimation, Tech debt.
- The SM wants this refined further in its own feature (it is "pretty straightforward but could be refined UI-wise").

### 13.6 Team dashboard (`Dashboard.dc.html`, screenshot 06)

- **Title row:** Team dropdown, Range dropdown ("Last 7 sprints"), Team/Train toggle, Export. Subtitle: "every number links to its definition and the stories behind it".
- **Speedometer gauges:**
  - Sprint predictability **94%** (2704, 50 of 53 SP, "In range · 85–115%").
  - PI predictability **82%** (PI-2026.4, 27 of 33 BV, "Below 85%").
  - Flow efficiency **38%** ("Healthy", "most wait is in Acceptance").
- **Normalized velocity tile** (dark, asanoha): 0.92 SP/day, "+0.03 vs last PI", sparkline.
- **Combo chart** "Velocity vs normalized velocity": committed SP (sand bars), completed SP (ink bars), SP/day line on the right axis (orange). Sprints 2642–2706; 2706 in progress (grey). Caption explains why normalized velocity is used: 2646's velocity fell 18%, but SP/day fell only 9%.
- **Donut** "Where the SP went": 108 SP done. Actual vs target per category (54/56, 17/15 in red, 13/14, 8/8, 8/7). Insight line: "SW maintenance is running 2 pts over its 15% allocation."
- **Planned vs actual capacity bars:** 2646 52.9/58.0 (−5.1), 2648 60.0/61.5, 2702 59.3/60.8, 2704 54.8/55.8, 2706 58.3/60.8.
- **Throughput bars:** 14, 16, 12, 17, 18, 7 (in progress). Average 15.4 items per closed sprint.

### 13.7 Settings (`Settings.dc.html`, screenshot 07)

Replaces the spreadsheet's `_Controller` sheet.

- **Sub-navigation:** Train and teams (PIs, iterations, teams); Members (roles, FTE, location); **Locations and holidays** (active); Work categories (colours and % split); Workflows and states (active vs waiting states); Capacity rules (deductions, hours per day); Thresholds (load and predictability bands); Backup and export (local data).
- **Locations and holidays page:**
  - Train dropdown; year segmented control (2026 / 2027 / 2028); "Refresh from public calendars"; "+ Company holiday".
  - Locations table: code badge, location, calendar source, time zone, member count, weekday holidays ("12 of 18"), last refreshed or edited; "+ Location".
  - **2027 holiday calendar** (70 holidays): a month × location grid, where each month row shows its PI (current PI tinted "now"). Holiday chips show day number, name and weekday. Legend: public / company / unconfirmed (dashed) / weekend.
- Only this sub-page is designed. The other Settings sections are still to design.

### 13.8 Icon sheet (`Icons.dc.html`, screenshot 08)

The design reference for the icon set (§15): principles, sections, size ramp (16/20/24/32), and menu states.

### 13.9 PI board interaction model: freehand, lines, multi-sprint cards (required; partly in the prototype)

This applies to both PI boards: the Team PI board (stories) and the ART program board (features, plus its Stories view).

**Freehand placement, like Miro**
- Cards can be placed **anywhere**: no grid snapping and no forced stacking. The SM arranges the board spatially, as on the Dyson Miro boards.
- **Layout and meaning are separate.** Where a card is dropped decides its *data*: the column(s) give its sprint(s), and the swimlane gives its project or team. That assignment happens explicitly on drop, with the target column and lane highlighted while dragging. The exact x/y position is stored separately (`BoardPlacement`) and never affects metrics.
- Moving a card within the same column and lane is purely visual. Moving it into another column re-plans the story, and a moved slice is recorded in the next commitment/version comparison.
- On the ART board, feature bars keep their **derived** horizontal span (from their own Team's Stories/Slices); their vertical position within the owning Team row is free. Features never span Teams or PIs.

**Dependency lines**
- Dependencies are drawn as **connector lines with arrows** (predecessor/provider → successor/consumer) between cards, on both boards. `from_story=A`, `to_story=B` means A is a prerequisite to starting B, without Feature/Project/Team restrictions.
- Line styles:
  - Delivery-flow links (same feature): solid, in the feature's swatch colour.
  - Cross-team dependencies: dashed ink.
  - Out-of-order or late links: red, with the plan-check warning.
- On the ART board, feature-level lines are **aggregated** from Story links (one per Feature pair with a count) and expand in Stories view. ExternalDependency records (outside the ART/department) can be shown in an optional **Dependencies** swimlane, linked to internal dependent work without fabricating Stories.
- Lines can get noisy, so offer a **Lines** dropdown: *All* / *Highlighted* (lines touching highlighted features; later also the selected card) / *None*. The prototype has this on the Team PI board (§13.1).
- Lines can be drawn on the board by dragging from a card's handle to another card, which creates a directed Dependency. A Stretch Story dependency applies to the **whole Story**, not a single slice.

**Stretch cards (multi-sprint)**
- A **stretch** can **span several Sprints within the same PI**. Its card is drawn **across those columns**, and the SM can resize it horizontally to change the span **without crossing a PI boundary**. Stretches can be declared and allocated capacity **at PI Planning**.
- When the span changes, the SM sets the points per sprint, e.g. 5 SP = 2 + 3. The default split is even, then editable. The card shows the split ("2 · 3 SP") and a **Stretch** marker that is visually distinct from committed cards (e.g. dashed edge, matching the dashed "uncommitted" convention).
- Committed cards cannot be stretched across columns; widening a committed card offers to convert it to a stretch.
- Column headers and load bars count **only the slice points** for that sprint.
- On the iteration board, a stretch appears in **each Sprint it occupies within its PI**, with that Sprint's slice points and a "1 of 2" badge.

**Implementation direction**
- **React Flow (xyflow, MIT)** is a natural fit for the PI boards. It provides free-positioned custom nodes, edges with arrows, handles to draw connections, pan/zoom and a minimap. Columns and swimlanes become a background/group layer.
- **dnd-kit** stays for the iteration board (Kanban columns) and for simple lists.
- This promotes React Flow from "if needed" to **the PI board engine**. Validate it in a short spike (or inside the Team PI board feature) before committing.

### 13.10 Screens not yet designed

- Work-item **details modal**, opened from the card's expand button (fields, dependencies, tasks, history).
- Sprint Planning (ceremony hours, tasking, unplanned deductions), plus **Start Sprint / Close Sprint** review/dialogues with effective date pickers and action timestamps (§11).
- Train dashboard.
- The remaining Settings sections.
- Feature/Project management views (roadmap staging: priority, target date, effort estimates).
- Backup/restore UI.

### 13.11 Work-item card spec (`Card.dc.html`, PI boards)

One card standard for every PI-board work item. `Card.dc.html` shows all eight variants at 2×.

**Size and shape**
- **225 × 100px** (2.25:1), **square corners**, white background, 1px `#E5DFD6` hairline. No shadow, no glow.
- A straight **4px left bar** in the **work-category colour** (drawn as its own element, so its ends stay square, not bevelled):
  - Feature development `#2E8B57`, Bugs `#C93A3A`, Enabler `#E8890C`, Estimation `#7A4CC2`, Tech debt `#3F4148`.
  - Overhead: General work `#A39C93`, Training `#5C7A1F`.

**Layout, top to bottom**
1. **Top row (22px):** a **feature strip** from the left bar to the points tag, holding the feature *name* (no feature ID) on the feature's pastel. Stories without a feature show "No feature" on `#F3EFE9` in muted text. At the right, the **points tag**: white on ink (`#1A1B22`), 11px semibold, e.g. "5 SP", "12 h" or "1.5 d".
2. **ID row (16px):** the key (e.g. PAY-439) on the left. **Right-aligned icons:** the Kumiko **warning** icon (plan-check issue) and the Kumiko **dependency** icon with the other team's name (e.g. "Bohol").
3. **Title:** 12.5px semibold, up to **2 lines**, then clipped.
4. **Expand button:** the Kumiko **expand** icon, ink on transparent, bottom right. It appears **on hover or keyboard focus** and opens the work-item **details modal** (not designed yet, §13.10).

**Not on the card:** work-item type label, status, category text, overhead detail lines, delivery-flow step numbers. Type and category are carried by the left bar and the legend.

**Variants**
- **Story** (Feature development, Enabler, Estimation, Tech debt) and **Bug**: as above. A Bug is its own work-item type, in the Bugs category only.
- **Feature card** (ART board, and the Features view): no left bar. The strip is the feature name on the feature's swatch with white text, then the points. Bottom line: "5 stories · 2702 → 2708" and a progress bar (3/5). The title is one bold line.
- **Overhead** (General work, Training): the strip reads "Overhead" on the neutral fill; ID such as GW-021 / TR-003, a title with an optional date ("Leadership town hall · Feb 10"), and hours or days in the tag. No story points, no velocity credit (§20, item 4).

**Anchors for dependency lines:** 8 per card: top and bottom edges at 25%, 50% and 75%, plus the middle of the left and right edges. They show as small square handles on hover.

---

## 14. Design system

### 14.1 Principles

- **Light theme.** Warm off-white page, white surfaces, black ink, orange accent.
- **Colour carries meaning.** The SM is a visual person: categories, features and states are all colour-coded.
- **Flat.** No outlines or shadows on cards and controls. Separation comes from fill contrast and spacing.
  - Exceptions: semantic red outlines on warnings and blocked items; the 1px hairline on work-item cards (§13.11); **dashed** borders for uncommitted objectives, dependency chips, unconfirmed holidays and cancelled absences; the navigation dropdown keeps its shadow.
  - Buttons and inputs explicitly use `border: 0` so browser defaults never show.
- **No sidebar, no top bar.** Maximise board space.
- **No keyboard-shortcut hints** anywhere in the UI.
- **Japanese woodworking motif:** the **asanoha** (hemp-leaf) kumiko lattice from the logo.

### 14.2 Tokens

**Core**

| Token | Value |
|---|---|
| Ink (text, primary buttons, dark tiles) | `#1A1B22` |
| Brand orange | `#E07F24` |
| Orange text (on light) | `#A65307` |
| Clock orange (viewer's zone) | `#C2650E` |
| Page background | `#F4F1EC` |
| Surface | `#FFFFFF` |
| Muted text | `#67635C` |
| Secondary text | `#3F3C37` |
| Active/selected tint | `#FCEFE2` |
| Current-sprint column tint | `#FFF8F1` / `#FFF3E6` |
| Hairlines inside tables | `#E7E2DA`, `#EFEAE3`, `#F3EFE9` |
| Asanoha stroke | `#E2D9CC` |

**Categories:** see §9.

**States:** New `#8A847C` · Active `#2F62C8` · Quality Check `#7A4CC2` · Acceptance `#C27A10` · Closed `#2E7D46`.

**Status pills (bg / text; no longer shown on PI board cards, still available for the iteration board and details):** Closed `#E3F2E7`/`#256B3B`, Active `#E6EEFB`/`#244FA3`, In QC `#EFE8FA`/`#5E3A9C`, Acceptance `#FBEFD9`/`#8A4F05`, New = plain.

**Feature pastels** (bg / border / swatch). Features are assigned from this palette:

| Name | bg | border | swatch |
|---|---|---|---|
| sky | `#E4EEFC` | `#A8C3EE` | `#4A7FD4` |
| aqua | `#DDF3F1` | `#96D3CC` | `#2A9D8F` |
| lilac | `#EEE7FB` | `#C3B0EC` | `#8B6BD1` |
| sand | `#F6EEDB` | `#DCC79A` | `#B8932E` |
| rose | `#FBE6EC` | `#EDB0C0` | `#CC5A7A` |
| moss | `#E8F1D9` | `#B9D394` | `#6E9A2E` |
| slate | `#E5E9F0` | `#B4BFCF` | `#5F6F86` |
| clay | `#F3E3DC` | `#D9B3A3` | `#A86A52` |

**Load and threshold chips (text on bg):** green `#256B3B` on `#E7F3EA` · amber `#8A4F05` on `#FDF3E1` · red `#B42318` on `#FDECEA`. Bar fills: green `#3E9A5B`, amber `#E9A23B`, red `#D9443A`.

**Gauges:** a speedometer (semicircle) gauge, built as custom SVG. Predictability scale 0–130% with ticks at 85, 100 and 115 and bands amber / green / red. Orange value arc, ink needle and hub, big value plus a small context line, and a band badge top-right ("In range · 85–115%", "Below 85%", "Healthy").

### 14.3 Typography

| Use | Font |
|---|---|
| Headings, page titles | **Zen Kaku Gothic New** (500/700) |
| UI and body | **IBM Plex Sans** (400–700) |
| Clocks, tabular numerics | **IBM Plex Mono** (500/600) |

- Bundle the fonts locally via `@fontsource` (no Google Fonts at runtime).
- Use `font-variant-numeric: tabular-nums` for numbers in tables and pills.

### 14.4 Shell and layout

- **Sticky header** (transparent, no bar). It stays at the top while the page scrolls, and content **fades out** under it through a gradient mask (the asanoha background continues behind it). Three groups:
  - **Left:** a 60px **logo button** that opens the **navigation dropdown** (closed by default).
  - **Centre:** the **today widget** (absent on Settings).
  - **Right:** **search** and **profile**.
- **Navigation dropdown** (white card with shadow; icons from the Kumiko set):
  - Plan: Team PI board, ART program board, Team PI brief
  - Capacity: Capacity planner
  - Sprint: Iteration board
  - Insights: Team dashboard
  - (Settings moved to the profile dropdown.)
- **Today widget:**
  - Line 1, one style (12.5px semibold `#3F3C37`): `yyyy/mm/dd · CWww.d | PI-2027.1 · Sprint 2706`. The pipe is muted `#8A847C`, weight 500, so it stays visible (CW is the ISO week; `.d` is the ISO weekday, 1 = Mon … 7 = Sun).
  - Line 2: up to **3 clocks** `HHMMh ZONE` (e.g. `0020h PHT  2150h IST  1020h CST`) in 18px IBM Plex Mono semibold. **Only the viewer's own time zone is orange** (`#C2650E`); the others are ink. Zone abbreviation is small and muted.
  - Times come from `Intl.DateTimeFormat` with time-zone aliases (`Asia/Calcutta → Asia/Kolkata`, `US/Central → America/Chicago`). Refreshes every 15s.
  - Sample zones: Asia/Manila (PHT), Asia/Kolkata (IST), America/Chicago (CST/CDT). The zones should come from the team's member locations (open question).
- **Search:** a 40px white circle with a magnifier icon. On click it expands to a 280px field with autofocus, and collapses on blur. The placeholder is per page (Settings: "Search settings…").
- **Profile:** a 40px ink circle with initials ("SM"). Clicking it opens a **profile dropdown** that holds **Settings**.
- **Page title row:** title (Zen Kaku Gothic New), **no subtitle**, an optional version chip, and on the right **all page controls**: Team/PI/Train/Sprint/Range selectors (as dropdowns), toggles, Export/Present and primary actions. Nothing else goes in the header.
- **Dropdown style:** white pill with a muted label prefix and a bold value ("Team **Palawan** ⌄").
- **Asanoha lattice background:**
  - Top-right of every screen: a square **80% of the page width**.
  - CSS radial mask from the top-right corner: opacity .9 → .6 at 55% → 0 at the edge. Stroke `#E2D9CC`.
  - It covers the today widget.
  - Also used inside the PI brief hero and the dashboard velocity tile (on dark).
  - The pattern tile is 28 × 48.5 (see the SVG `<pattern id="asanohaBg">` in any screen).
- Panels: white, radius ~12–16px, no border, no shadow. **Work-item cards are the exception**: square corners with a hairline (§13.11).
- **Baseline viewport: 1440 × 900.** Every screen is designed and checked at this size. Pages are fluid and stretch wider; content taller than 900 scrolls under the sticky header. On the design canvas, every screen is 1440 wide and its artboard height matches its content (the Team PI board is exactly 1440 × 900).

### 14.5 Logo

`assets/azusa-logo.png`: a hexagonal kumiko/asanoha mark in black, white and orange. The asanoha detail blurs to a solid when too small, which is why the header logo is 60px.

---

## 15. Icon set ("Kumiko line")

Source: `icons/icons.json` (inner SVG for a 24×24 viewBox) and `icons/svg/*.svg` (standalone files). Reference sheet: `Icons.dc.html` / screenshot 08.

**Rules:**

- 24px grid, **1.75px stroke**, mitred joins, butt caps, no fill unless stated.
- 60° hexagon and triangle geometry.
- Ink (`currentColor`) with an optional **orange** (`#E07F24`) detail. Dark fills use `currentColor` so they follow the icon colour in every state.
- Size ramp: 16 / 20 / 24 / 32.

| Icon | Design |
|---|---|
| team-board | 3×2 grid frame, top-middle cell filled orange |
| art-board | Frame with 3 rows of solid 2.5px bars, top bar orange |
| pi-brief | Document with folded corner, orange title block, 3 text lines |
| capacity | Hexagon outline, lower half filled orange, no middle line |
| iteration | Kanban board with 3 equal columns; cards 3/2/1, last card orange |
| dashboard | Half-hexagon gauge, orange needle and hub |
| settings | Hex nut |
| search | Hexagonal lens rotated 15°, handle at 45° from the centre of an edge |
| add / filter / export | Plain plus; funnel; box with arrow |
| present | Triangle with orange inner triangle |
| refresh | Open hexagon loop with a large solid `currentColor` arrowhead, top-right corner open |
| chevron | 60°-style chevron ("Open menu") |
| expand | Two opposed corner arrows (top-right and bottom-left); opens a card's details |
| dependency | Two linked hexagons, all ink |
| delivery-flow | Hexagon of 6 triangles; first two ink with a white divider, third orange |
| objective | Nested hexagons, orange centre |
| risk | Diamond quartered, top quarter orange (ROAM) |
| warning (plan check) | **Solid orange triangle with an ink "!"**, no outline (distinct from risk) |
| velocity | Ink baseline, orange zigzag with arrowhead |
| calendar (holidays) | Calendar frame with a small orange asanoha star |
| location | Hexagonal pin with an orange hexagon centre |
| clock | Hexagon with hands |
| members | Hexagonal head with shoulders |
| asanoha | Brand mark for empty and loading states |

**Status:** the Team PI board and card sheet now use the Kumiko **warning**, **dependency** and **expand** icons. Most other screens still use simple glyphs; applying the set there is a small design-polish task. A **Legend** icon is still missing from the set.

**Known quirk:** delivery-flow's white divider shows as a seam on non-white backgrounds. Use a background-coloured divider or a gap instead.

---

## 16. Technology stack and architecture

Chosen for **security and privacy, reliability, and expansion**, local-only, with modern, fluid charts.

| Concern | Choice | Notes |
|---|---|---|
| Language | **TypeScript** (strict) | End to end |
| App | **Next.js**, a single app | Runs locally; no deployment |
| Database | **PGlite** (embedded Postgres in WASM) + **Drizzle ORM** | Real Postgres semantics, a local file, and a migration path to server Postgres if it ever goes multi-user |
| Validation | **Zod** | Shared schemas for forms, API and import |
| Unit tests | **Vitest** | **Golden tests** for the capacity/metrics engine, reproducing the spreadsheet and the prototype numbers |
| E2E tests | **Playwright** | |
| Charts | **shadcn/ui charts (Recharts)** + a custom SVG speedometer gauge | Fallback: **Apache ECharts** with a custom theme. A **chart spike (feature 005)** decides |
| PI boards | **React Flow (xyflow)** | Freehand card placement, dependency lines, pan/zoom (§13.9) |
| Drag and drop | **dnd-kit** | Iteration board (Kanban) and lists |
| Holidays | **date-holidays** (ISC) | Seed data per location and subdivision |
| Fonts | **@fontsource** packages | Bundled locally |
| Auth | **Better Auth**, deferred | Only when multi-user. The model already records created_by/updated_by and roles |
| Data safety | Automatic local backups plus export/import | Backup and export in Settings |

**Architecture notes**

- The **capacity and metrics engine is a pure TypeScript module** (no I/O). Inputs include explicit Team Sprint date windows (including permitted working-day offsets) and commitment references; outputs are numbers and explanations. It is testable and reusable across dashboards.
- **History first:** StateChange, full Plan Version snapshots, and PI/Sprint Commitment records with Actuals lifecycle exist as separate concepts from the first relevant work-item and lifecycle features (§11).
- **Derived values are computed, not stored:** spans, teams-on-project, cross-team flags, load.
- **RBAC is designed now and enforced later:** Admin, RTE, SM, Team member, Business Owner (tentative).

---

## 17. Lessons from the predecessor spreadsheet (`PI_Planner_v3.2.xlsx`)

| In the sheet | In Azusa |
|---|---|
| `_Controller` dev list with 13 fixed slots | Member records, unlimited |
| PI/sprint dates derived from PI name + ISO week + `Offset Control` | Explicit PI and Iteration dates |
| Holidays table for one locale | Holidays per location; the member's location decides which apply |
| Capacity table: Leaves / GW / SI / Cap per member per sprint, `Count` multiplier | Absence + Deduction + `fte_factor` |
| Guide % vs Override % per category | Category.default_pct vs TeamCategoryAllocation |
| C / S / U designation; Done / Not Done / Dropped | Story.designation; Story.state |
| Sprint outcome thresholds | Configurable predictability thresholds |
| SW-maintenance designations | Separate Bug work-item type with its own workflow and required Bugs category |
| Sprint1 leave calendar codes (planned / unplanned / cancelled / half-day / WFH…) | AbsenceType + planned flag + status |
| Sprint1 Scrum events table | CeremonyTemplate |
| Roadmap staging: priority, LE, EEv1/EEv2 | Feature.priority, target_date (LE), effort_estimates[] (EE revisions) |
| `Ave Vel (SP/md)` typed by hand | Computed 4-sprint rolling normalized velocity |
| Fixed row blocks ("do not insert rows after this one") | Gone |

**Bugs in the unfinished sheet, which Azusa resolves:**

1. *Capacity Utilization* divided planned SP by dev days directly. Azusa compares planned SP with forecast SP (days × NV).
2. Roadmap "Total Planned (man-days)" also summed the dev-capacity row. Not carried over.
3. A blank category override counted as 0%. Azusa treats unset as inherit.

**Out of scope:** "Ti / Rm / Ob" are the SM's personal per-feature checklist.

---

## 18. Proposed milestones and features

The SM will pass these to ChatGPT. They are proposals: ChatGPT owns the briefs, and may split or merge features with a rationale.

**M0 — Foundations**

- **001 Project setup and conventions:** Next.js + TS strict, PGlite + Drizzle, Zod, Vitest, Playwright, lint/format, folder conventions, `created_by`/`updated_by` plumbing, backup-on-start, app shell, fonts, tokens and Kumiko icons. Reserve separate domain concepts for Plan Version, PI/Sprint Commitment, Actuals and audit timestamps; no premature auth enforcement.
- **002 Calendar and people:** Train, Team, Member (role, FTE, location), Location, Holiday, PI and Iteration, AbsenceType and Absence. **Admin/RTE-configurable Sprint count, duration, explicit dates and names; ART-shared cadence with optional ±1 working-day Team stagger.** Settings: Train/Teams, Members, Locations/Holidays. Prototype YYWW/two-week/fixed-quarter dates are samples.
- **003 Capacity engine:** pure TS module (§8) with golden tests; deduction modes; hours/day; NV with seed/rolling window; Capacity planner screen. Handle variable-length Team Sprint windows and ±1 working-day offsets. **Training, Retro, General Work are non-story overhead deductions** with no Project or SP.
- **004 Categories and allocation:** Category (kinds), train defaults, team overrides with inherit, 100% validation, per-PI fixing, category budgets; Settings › Work categories; the split card on the Capacity planner.
- **005 Chart spike:** Recharts/shadcn vs ECharts against the dashboard designs (gauge, donut, combo, bars), including **cross-filtering, drill-through and tooltips** (§12.1); pick one; build the gauge component.

**M1 — Team PI planning**

- Work items: Project, **single-Team Feature** (same-Team Stories, one PI), project-parented Story (Feature optional) and separate **Bug** type restricted to Bugs category; Stretch StorySlices may span Sprints within one PI only; Task model and detail drawer. Preserve PI Objective vs Story designation independence.
- Team PI board: Project × Iteration on React Flow, with freehand placement, multi-sprint cards with point splits (StorySlice), the §13.11 card, feature highlight, filters/legend/lines controls, zoom and load headers.
- Dependencies and delivery flow: directed **predecessor → successor** links across Features/Projects/Teams, Stretch Story dependencies apply to whole Story; separate **ExternalDependency** records with optional Dependencies swimlane for outside-ART prerequisites; derived cross-team flags, order checks and advisory plan checks (issues button + modal, §13.1).
- Capacity hints on the boards (load bars and pills, per-category option).
- **Plan versioning** (full user-created vN plan snapshots) and **Start PI** (Admin/RTE) creating official PI Commitments are **separate**. Compare to version vs compare to commitment; historical records never overwritten.
- Team PI brief (objectives with BV, risks with ROAM, confidence vote, export PDF, present mode).

**M2 — Sprint execution**

- Workflows and states (active/waiting/done, WIP limits) and StateChange history.
- Iteration board.
- Sprint Planning: ceremony template hours, tasking, unplanned deductions, and **Start Sprint** (SM) review of current Sprint Plan + effective-date picker → official Sprint Commitment. Permit retroactive start without reconstructing an earlier backlog; record action timestamp separately.
- **Close Sprint** (SM): effective-date picker (early/late clerical close allowed without changing official dates), review and finalize Actuals, including stretch slices; persist recorded-at timestamp and execution history (§11).

**M3 — Metrics and dashboards**

- Metrics engine (§12) with golden tests, exposing filterable facts, and reading **PI Commitment vs Sprint Commitment vs Actual** correctly (not manual vN by default).
- Team dashboard, with the Power BI-like interactions (§12.1).
- Train dashboard, with the same interactions plus drill-down to teams.
- Reporting export (PNG/PDF, CSV).
- Plan-trail insights (PI Commitment → Sprint Commitment → Actuals): estimate drift, plan stability, scope change, stretch delivery (§11.1).

**M4 — ART level**

- ART program board with roll-ups, milestones, cross-Team and **external** dependencies, and the dependency table; each Feature appears in exactly its owning Team row.
- Auth (Better Auth) and RBAC enforcement **only if** multi-user becomes real.

**Later:** bug and maintenance metrics; self-service days off; per-location hours/day.

---

## 19. Sample dataset used in the prototype

Use it for seed data and golden tests.

**Train:** Payments ART.

| Team | Area | FTE | Load by sprint (2702–2710) |
|---|---|---|---|
| **Palawan** | Checkout, 6 locations | 7.5 | 93 / 98 / 105 / 85 / 70 % |
| Siargao | Vault | 6 | 88 / 97 / 90 / 85 / 80 |
| Bohol | Merchant | 5 | 72 / 80 / 91 / 112 / 95 |
| Cebu | Risk | 6.5 | 99 / 103 / 96 / 94 / 90 |

**Palawan members** (all Developer 1.0 FTE unless noted). Leave days by sprint 2702 / 2704 / 2706 / 2708 / 2710:

| Member | Initials | Location | Avatar colour | Leave days |
|---|---|---|---|---|
| Andrea Santos | AS | PH | `#2F62C8` | 0/2/0/0/1 |
| Ben Cruz | BC | PH | `#11806F` | 1/0/0/3/0 |
| Carlo Reyes | CR | SG | `#7A4CC2` | 0/0/2/0/0 |
| Dana Lim | DL | AU-WA | `#B8407E` | 0 |
| Enzo Garcia | EG | IN | `#C93A3A` | 2/0/1/0/0 |
| Faye Tan | FT | UK | `#5C7A1F` | 0/0/0/1/0 |
| Gio Mendoza | GM | US-TX | `#A65307` | 0/3/0/0/2 |
| Hana Villanueva | HV | PH | `#5F6F86` | 0 (New joiner, 0.5 FTE) |

**Projects and features (Palawan):**

| Project | Feature | Pastel |
|---|---|---|
| Saved Payments | F-112 Saved cards | sky |
| Saved Payments | F-125 Card updater | aqua |
| Checkout Revamp | F-118 Address autofill | lilac |
| Checkout Revamp | F-119 One-page checkout | sand |
| Checkout Revamp | F-121 Wallet pay | rose |
| Platform Hygiene | (no feature) | — |

**Other teams' features:**

| Team | Features |
|---|---|
| Siargao | F-201 Tokenization API v2 (slate), F-205 Token migration (moss), F-208 Key rotation automation (clay) |
| Bohol | F-305 Merchant onboarding v3 (moss), F-301 Merchant certificates (slate, late) |
| Cebu | F-401 Rules engine (clay), F-404 Velocity checks (lilac), F-406 Analyst console (aqua) |

**Palawan sample work items (PI-2027.1).** The original prototype labels all cards "stories" even when representing Bugs; the implementation must seed **separate Bug work-item types** for those entries. Columns: Sprint · key · title · SP · category · state · flow step / notes.

*Saved Payments*

| Sprint | Key | Title | SP | Category | State | Flow step / notes |
|---|---|---|---|---|---|---|
| 2702 | PAY-421 | Store card token on consent | 5 | FD | Closed | step 1; depends on Siargao VLT-18 Tokenization API v2 (2702) |
| 2704 | PAY-438 | List saved cards on pay step | 8 | FD | Closed | step 2 |
| 2704 | PAY-447 | Remove a saved card | 5 | FD | Closed | step 4 · **out of order** (planned before step 3) |
| 2706 | PAY-439 | Default card selection | 5 | FD | Active | step 3 |
| 2708 | PAY-452 | Saved-card analytics events | 3 | FD | New | step 5 |
| 2706 | PAY-460 | Card updater webhook | 8 | EN | In QC | F-125 |
| 2708 | PAY-461 | Expiry refresh job | 5 | FD | New | F-125 |
| 2710 | PAY-462 | Updated-card notifications | 5 | FD | New | F-125 |

*Checkout Revamp*

| Sprint | Key | Title | SP | Category | State | Notes |
|---|---|---|---|---|---|---|
| 2702 | PAY-430 | Autofill provider spike | 3 | ES | Closed | F-118 |
| 2702 | PAY-433 | Address autocomplete field | 8 | FD | Closed | F-118 |
| 2704 | PAY-434 | Address validation rules | 8 | FD | Closed | F-118 |
| 2704 | PAY-470 | One-page layout skeleton | 8 | FD | Closed | F-119 |
| 2706 | PAY-471 | Inline payment step | 13 | FD | Active | F-119 · BLOCKED on the iteration board |
| 2708 | PAY-472 | Order summary panel | 8 | FD | New | F-119 |
| 2710 | PAY-473 | Rollout flag and A/B split | 3 | EN | New | F-119 |
| 2708 | PAY-480 | Apple Pay merchant setup | 5 | EN | New | F-121 · needs Bohol MER-52 Merchant certificates, planned 2710 → **late** |
| 2710 | PAY-481 | Google Pay button | 8 | FD | New | F-121 |

*Platform Hygiene (no feature), by sprint*

| Sprint | Stories |
|---|---|
| 2702 | PAY-B01 Bug budget (triage) 8 SW · PAY-D90 CVV field loses focus on iOS 3 SW · PAY-D94 Refund rounding error 5 SW · PAY-T12 Upgrade payments SDK to v9 8 TD · PAY-N40 Token vault TLS rotation 9 EN · PAY-E31 Estimate: loyalty points 3 ES (all Closed) |
| 2704 | PAY-B02 Bug budget 8 SW · PAY-T13 Remove legacy 3DS v1 path 8 TD · PAY-E32 Estimate: BNPL provider 5 ES (Closed) |
| 2706 | PAY-B03 Bugs: 3 picked from triage 8 SW (Active) · PAY-N42 Load-test checkout API 8 EN (New) · PAY-T14 Split checkout service module 6 TD (Acceptance) · PAY-E33 Estimate: multi-currency 5 ES (Closed) · PAY-E35 Estimate: wallet tokens 5 ES (New) |
| 2708 | PAY-B04 8 SW · PAY-N41 Payment logs to new pipeline 9 EN · PAY-T16 Retire old card form 4 TD · PAY-E34 Estimate: refunds self-service 2 ES |
| 2710 | PAY-B05 8 SW · PAY-T15 Dependency upgrades 5 TD · PAY-N43 Observability dashboards 5 EN · PAY-E36 Estimate: saved-card limits 4 ES |

**Planned vs forecast (Team PI board headers):** 52/56 (93%), 50/51 (98%), 58/55 (105%), 44/52 (85%), 38/54 (70%).

**Cross-team dependencies (ART board):**

| Needing story | Providing story | Needed | Planned | Status |
|---|---|---|---|---|
| Palawan PAY-480 | Bohol MER-52 Merchant certificates | 2708 | 2710 | **Late by 1 sprint** |
| Palawan PAY-421 | Siargao VLT-18 Tokenization API v2 | 2702 | 2702 | Same sprint |
| Cebu RSK-12 Score saved-card payments | Siargao VLT-24 Token events stream | 2706 | 2704 | On time |
| Bohol MER-30 Embedded checkout for merchants | Palawan PAY-471 Inline payment step | 2710 | 2706 | On time |
| Siargao VLT-31 Migrate stored tokens | Cebu RSK-09 Rules engine read API | 2708 | 2706 | On time |

**Iteration board 2706 cards:**

| Key | Title | SP | Cat | Feature | Tasks | Who | Age / flags |
|---|---|---|---|---|---|---|---|
| PAY-N42 | Load-test checkout API | 8 | EN | — | — | BC | New |
| PAY-E35 | Estimate: wallet tokens | 5 | ES | — | — | GM | New |
| PAY-D99 | Receipt email missing card brand | 3 | SW | — | — | HV | New |
| PAY-439 | Default card selection | 5 | FD | F-112 | 3/5 · 9h | AS | Active, 3 days |
| PAY-471 | Inline payment step | 13 | FD | F-119 | 2/7 · 26h | CR | Active, 4 days, **BLOCKED** |
| PAY-D97 | Saved-card list flickers on Android | 3 | SW | — | 1/2 · 3h | FT | Active, 1 day |
| PAY-460 | Card updater webhook | 8 | EN | F-125 | 4/4 | EG | 1 day in QC |
| PAY-T14 | Split checkout service module | 6 | TD | — | 3/3 | DL | Acceptance, "Waiting for PO" |
| PAY-E33 | Estimate: multi-currency | 5 | ES | — | 2/2 | GM | Closed Feb 3 |
| PAY-D98 | Wrong currency symbol on receipt | 2 | SW | — | 1/1 | FT | Closed Feb 5 |

> The sample numbers are internally consistent within each screen, but **not everywhere across screens.** For example, the iteration board's 58 SP for 2706 matches the PI board, but its card list is a subset. Re-derive seed data from one source when building.

---

## 20. Decisions log

**Operator-approved clarifications (2026-11-08; supersede contradictory older wording)**

1. **Cadence:** Admin/RTE configures each ART’s PI/Sprint count, Sprint length, dates and custom names. Optional `YYWW` convention refers to the Sprint’s ISO **ending week**; not a mandatory format. ART Teams share a cadence, with a Team-specific **lead/lag no greater than one working day** for operational/ceremony scheduling. Sprint date math uses the applicable Team schedule.
2. **Ownership:** Each Feature is owned by **exactly one Team** and one Project, and contains only Stories owned by that same Team and Project. If a different Team legitimately does significant work, break down the Feature and use cross-Team dependencies. Projects may involve multiple Teams. Stories and Bugs always have a parent Project; Story may have no Feature.
3. **Work-item types:** Bug is a distinct work-item type from Story, and Bugs may be allocated only to the **Bugs** work category. Enabler and technical-debt work remain Stories. The sample "SW maintenance" terminology may be adapted to the Bugs category; do not conflate type and category.
4. **Overhead:** Training, Retro and General Work are **non-story time/capacity activity/deduction records**, no Project required, no SP or velocity credit. Development capacity is calculated after these deductions.
5. **Dependencies:** `from_story` is the **predecessor/provider** and `to_story` is the **successor/consumer**; `A → B` means A must finish before B starts. Cross Feature, Project, Team as needed. Stretch dependency applies to **whole Story**. External prerequisites outside ART/department are **ExternalDependency records** linked to internal work, with optional **Dependencies** swimlane (hardware test rig example).
6. **PI boundaries:** Feature, Story and Stretch slices **cannot span multiple PIs**. PI Objective commitment and Story commitment designation are **independent**.
7. **Versioning:** User-created v1/v2/v3… captures the **complete PI planning state** at the point of revision, preserving earlier plan versions. A mid-PI v3 includes unchanged v2 planning content plus new changes. **Versioning is not commitment.**
8. **Commitment lifecycle:** **Start PI (Admin/RTE)** records the then-current PI Plans as official PI Commitments for participating Teams; **Start Sprint (SM)** records reviewed current Sprint Plan as that Team’s Sprint Commitment; **Close Sprint (SM)** finalizes Actuals. Do not call these actions "freezing" or "Baseline the PI" in the UX.
9. **Retroactive Sprint actions:** Start Sprint / Close Sprint show **date pickers** for effective lifecycle dates; persist scheduled Team Sprint boundaries and true action timestamps separately. SM can start late due to clerical work or close early for holidays/ceremonies or later (e.g. next Sprint Day 1), without rewriting planned end dates. On **Start Sprint**, show current backlog counts/SP, capacity, load and warnings. After explicit SM confirmation, commit **the current reviewed plan**, even if the effective date is backdated. Example: 40 SP Monday → 48 SP Tuesday → late Start Sprint Wednesday effective Monday → **48 SP Sprint Commitment**. No forced historical reconstruction or automatic rejection based on advisory planning warnings.
10. **Board placements:** Layout belongs to specific Team/ART + PI board instances; Feature single-Team ownership is unaffected by a Feature having representations in multiple views.

**Prototype refinements (2026-11-09, operator-directed)**

11. **Baseline viewport 1440 × 900.** Designs are checked at this size; pages stretch wider and scroll vertically.
12. **Work-item cards** follow §13.11: 225 × 100, square corners, white, category left bar, feature-name strip, ink points tag, right-aligned icons, hover expand, 8 line anchors.
13. **Team PI board controls:** issues button opening a Plan checks modal; Lines dropdown (All / Highlighted / None); Filters bar (Team, PI, View, multi-select Highlight); Legend bar; zoom with Fit. The Feature focus bar, delivery-flow strip and bottom checks panel are gone.
14. **Board geometry:** two card columns per sprint column; lane names rotated in a narrow column; white board.
15. **Shell:** no page subtitles; sticky header with a fade line; Settings lives in the profile dropdown.
16. **Visual taste:** no warm-grey boards or cards, no glows. Secondary affordances (e.g. expand) stay quiet: ink on transparent. A red outline marks a plan issue; how risks are marked on cards is still open.

**Other existing decisions retained:** Local-only standalone personal project, no paid APIs; team + ART scope only; freehand React Flow PI boards with StorySlice stretch allocations and arrows; dnd-kit iteration board; normalized velocity = 4-Sprint ratio of sums; capacity days for PI and hours for Sprint; per-location holidays and absences; explicit project hierarchy; configurable train categories and team allocations; workflow history from day one; built-in interactive Power BI-like team/train dashboards; SDD agent roles (§3); light kumiko/orange design (§14–15).

## 21. Assumptions, open questions and known gaps

**No blocking architecture questions remain from the operator’s review.** Do not reopen resolved cadence, ownership, overhead, dependency, PI boundary, versioning or commitment semantics without genuinely new evidence. Detail-level choices should be handled in the feature that implements them.

**Later feature-specific questions (defer):**

- Holiday calendar confirmation (e.g. the 2027 Philippines EDSA Revolution Anniversary classification, lunar/Islamic estimates) and per-location hours/day overrides (§10 / Calendar feature).
- Which 3 time zones to show in the Today widget: pinned user choice or Team locations (shell/UI feature).
- Exact choice of US/India regional holiday subdivisions beyond prototype samples (Locations feature).
- Whether remaining prototype toggle controls become dropdowns; the prototype is UI intent, not final specification (screen-specific features).
- Business Owner role remains tentative until RBAC is implemented (later).
- Acceptance workflow-state typing, flow-efficiency gauge thresholds, and WIP hard/soft behavior (workflow/metrics features).
- Curated interactive dashboards are in scope; a user-built report designer is **out of scope unless explicitly requested** (§12.1).
- **Sprint predictability formula** remains a placeholder until the operator supplies it when building dashboards (§12).
- Technical detail of selecting working-day offsets around multiple country holidays and PI-edge dates should be specified with deterministic tests when implementing calendar rules; **the one-working-day cap is already approved**.
- **Bug capacity at PI Planning (M1 work-items feature).** Bugs are a separate type restricted to the Bugs category, but most bugs don't exist yet at PI Planning; the sample used "Bug budget" placeholder cards (PAY-B01…B05). Decide how the Bugs allocation is planned before the bugs exist, e.g. a placeholder Bug, or a category capacity reservation per Sprint that real Bugs draw down. Also decide whether Bugs carry SP (affects velocity and the Bugs budget check).
- **End-of-PI carry-over (M1 work-items / Start PI feature).** Features, Stories and slices cannot cross a PI, so define what happens to unfinished work at PI end: e.g. close the original as not done and create a linked continuation Feature/Story in the next PI, preserving the trail. This affects PI predictability and the plan trail.

**Prototype limitations (not new requirements):**

- Live Today clock uses real current date while sample dataset shows Feb 2027.
- Kumiko icons are applied only on the Team PI board and the card sheet so far.
- The Team PI board shows freehand-looking cards and dependency lines, but cards can't be dragged, lines can't be drawn, and there are no multi-sprint stretch cards; §13.9 supersedes screenshots. The ART program board and iteration board still use the older card style (§13.11 applies to them too).
- The delivery-flow icon’s divider may show a white seam on coloured backgrounds.
- Only Settings › Locations and holidays is designed; other Settings pages, Story details, Sprint Planning, Train Dashboard, project/feature management and backup UI still need design.
- Sample numbers/fixtures are not fully reconciled across screens. Derive the real seed dataset and golden tests from **one canonical source**, not separate screenshot arrays.

## 22. Prototype package: contents and how to read it

```
azusa-handoff/
├── AZUSA_HANDOFF.md            ← this file
├── README.md                   ← package index
├── prototype/                  ← hi-fi screens (source)
│   ├── Main.dc.html            Team PI board
│   ├── ProgramBoard.dc.html    ART program board
│   ├── Capacity.dc.html        Capacity planner
│   ├── PIBrief.dc.html         Team PI brief
│   ├── TeamIteration.dc.html   Iteration board (2706)
│   ├── Dashboard.dc.html       Team dashboard
│   ├── Settings.dc.html        Settings › Locations and holidays
│   ├── Icons.dc.html           Icon reference sheet
│   ├── Card.dc.html            Work-item card variants at 2× (§13.11)
│   └── canvas.json             Board layout on the design canvas
├── screenshots/                ← PNG renders of every screen (1440px wide; card sheet 2040px)
├── icons/
│   ├── icons.json              name → inner SVG (24×24 viewBox)
│   └── svg/*.svg               standalone icons (stroke 1.75, currentColor + #E07F24)
├── assets/
│   ├── azusa-logo.png
│   └── azusa-logo-256.png
└── docs/
    └── azusa-data-model.md     data model v0.4 (operator-aligned canonical conceptual model)
```

**The `.dc.html` format** (from the Claude design canvas):

- Each file is HTML markup inside `<x-dc>`, with inline styles. The `<helmet>` block holds fonts and global CSS.
- **Holes:** `{{path}}` inserts values (text or attribute), e.g. `style="{{c.style}}"`, `{{s.title}}`.
- **Loops:** `<sc-for list="{{cols}}" as="c"> … </sc-for>`.
- **Conditionals:** `<sc-if value="{{c.now}}"> … </sc-if>`.
- **Data and logic:** the `<script type="text/x-dc" data-dc-script data-props='…'>` block defines `class Component extends DCLogic`.
  - `renderVals()` returns every value the markup uses.
  - The **sample data arrays live in `pageVals()`**: stories, members, holidays, metrics.
  - It also holds the shared header logic: menu state, search state, today-widget clock.
  - `data-props` lists designer-editable props (e.g. `menuOpen`, `filtersOpen`, `legendOpen`, `checksOpen`).
- `./support.js` (the canvas runtime) is **not** included. The files will not render by double-click; read them as source and use `screenshots/` for visuals.
- `/_blob/eb2c6d73f86feb942c6986c10c979040` is the logo (`assets/azusa-logo.png`).
- Inline styles are prototype-only. In the real app they become design tokens and components.

---

## 23. Guidance for writing the feature briefs

- One brief per feature. Each brief should name:
  - its **milestone**
  - the **wants (§5)** it serves
  - the **entities (§7)** it introduces or touches
  - the **screens (§13)** it delivers or changes
  - **acceptance criteria** that UAT (Claude Code + SM) can execute
  - **out-of-scope** items
- Engine features (capacity, metrics) must list their **golden test cases** with expected numbers (§8, §19).
- Reference the prototype as **intent** ("layout per screenshot 03"), and call out the deltas this document specifies (e.g. apply the Kumiko icons, dropdowns over toggles).
- Keep briefs grounded: it is a local learning project with no hosting, auth or monetisation unless the brief is explicitly about them.
- Separate what is **critical** for the feature from **improvements that can wait** and **future enhancements**.
- Carry remaining **feature-specific** open questions (§21) into the brief that first needs them; do **not** reopen resolved operator-approved requirements from §20.
- Explicitly differentiate **manual Plan Versions** from **Start PI → PI Commitment**, **Start Sprint → Sprint Commitment**, and **Close Sprint → Actuals** (§11). Include SM review/current-plan commitment on retroactive Starts and the working-day cadence offset in the relevant feature briefs.
- Use the supplied prototype/screenshots/assets only; do not introduce unrelated illustration assets into Azusa.
