# Azusa — Data Model & Capacity Formula (v0.6)

**Status:** Operator-clarified conceptual data model · v0.4 2026-11-08, v0.5 2026-11-20 (brought in line with the hi-fi prototype: Sprint planning 5p, Team calendar 3b–3d, Work item 5w), **v0.6 2026-11-20** (work item variants: Bug 5w-b and light story 5w-l; see `azusa-work-item-view.md`). This is **not** a finalized physical database schema. See `../AZUSA_HANDOFF.md` §§7–12, 20–21 for the detailed requirements and source decisions.

**v0.5 changes at a glance:** Story statement/description/target/milestone/owner fields · **Removed** state with reason · AC / DoR / DoD **three-state checklists** + team DoR/DoD templates · **universal Tags** · Blocked flag · team-level dated **Milestones** · dated per-Sprint **ceremonies and meetings** · **overhead reserve + tickets** · **Buffers** · planning style (Owner / Distributed) · Sprint velocity override · extended Sprint Commitment snapshot · one stated exception to "no SP↔hours".

**v0.6 changes at a glance:** Bug fields (**severity**, environment, version, device/OS, ordered **repro steps**, expected / actual result) · Bug workflow finalized (Triage → Investigating → Correcting → Verification → Closed + Removed) · Removed reasons per type · **no priority field** (backlog rank is priority) · Story **layout variant derived from category** (full vs light) · checklist templates per work-item kind · bugs have no AC list.

## 1. Scope, ownership and rules

- Team-level and Agile Release Train (ART)-level SAFe planning; personal, local-only project. No portfolio/large-solution layer for now.
- **Project** is long-lived; it can involve multiple Teams, derived from the Team ownership of its related work items. It has no own PI boundary.
- **Feature/Epic** (one entity with configurable display label) has a required Project, **one owning Team**, and **one PI**. Only Stories owned by that Team and Project may belong to the Feature. Legitimate work by another Team is split into its own Feature/Stories, linked with dependencies.
- **Story** has a required Project and owning Team; Feature is optional. Enablers, Estimations and technical-debt work are Stories (the **light** variant, see *Work item layouts*).
- **Bug** is a **separate work-item type** with a required Project and Team and is restricted to the **Bugs** work category. It is not modeled as a Story merely categorized as Bugs. The prototype uses the sample category name "SW maintenance (bugs)"; the real setup can use a Bugs label. **Support work also counts as SW maintenance.**
- **Training, Retrospective and General Work** activities are **non-story** capacity/activity entries; they require no Project and contribute **time deductions, not Story Points**. Do not count the same effort both as Story Points and overhead.
- A Feature, Story or Stretch slice **cannot cross a PI boundary**. A committed Story has one Sprint slice; Stretch Stories may have multiple Sprint slices **within one PI**. A Story may also sit in a PI with no Sprint, or in the unscheduled backlog with **no PI**.
- PI Objective committed/uncommitted is **independent** of Story committed/stretch/unplanned designation.
- **Priority is the backlog rank** (PO-ranked list). There is no separate priority field on any work item.

## 2. Conceptual entities

These names convey domain concepts; the implementer may normalize or combine tables as appropriate while maintaining the rules.

### Organisation and calendar

| Entity | Key fields / relationships | Invariants |
|---|---|---|
| Train (ART) | name, default work categories, calendar settings | Owns the PI/iteration cadence |
| Team | train, name, hours_per_day (default **8.0**), deduction mode, `sprint_offset_workdays`, **planning_style** (`owner` \| `distributed`), DoR/DoD templates | Shares ART iteration identities; offset is **−1, 0 or +1 working day**. Planning style is snapshotted into each Sprint Commitment |
| Member | team, name, nickname, initials, role, `fte_factor`, location | PO/SM do not contribute development capacity; FTE handles part-timers/new joiners |
| User / Role | Admin, RTE, SM, PO, Team member, tentative Business Owner | Single user now; RBAC enforced later. Preserve `created_by`, `updated_by`, timestamps |
| PI | train, name, configured start/end, lifecycle status | Admin/RTE configures PI boundaries and uses **Start PI** to establish all participating Team PI Commitments |
| Iteration (Sprint) | PI, name, scheduled start/end, kind (development/IP) | Admin/RTE controls count, length (2/3/4 weeks), dates and custom names; **YYWW is optional**, based on the ISO ending week |
| Team Sprint schedule | team, iteration, scheduled start/end or configured relative offset | Team-specific one-working-day stagger does not change ART iteration identity |
| Location | country, optional subdivision, time zone, calendar source | Member-based local holidays govern capacity |
| Holiday | location, date, portion, source, confirmed | Library seed + company/manual overrides |
| Absence / AbsenceType | member, date, portion, type, planned, active/cancelled; `affects_capacity`; optional `extra_hours` | Leave/sick reduce capacity; WFH/business trip are attendance only; **planned overtime** adds hours (+2 h in the prototype). Leave is always dated — "reserve a day" is parked on a placeholder date and moved later |
| **SprintCeremony** | team, iteration, date, name, duration | Entered per Sprint with dates (**no fixed-day template**); whole team attends; drives cell hours and date-header highlight |
| **Meeting** | team, date, name, duration, attendees (whole team or listed members) | Deducts hours only from attendees on that date |
| **Milestone** | **team**, date, name; `scope` (`team` now; `train` reserved for ART board later) | Entered by SM/PO on the Team calendar (click a date). Generic type only, no categories. Does **not** affect capacity. Date header shows milestone red, taking precedence over the ceremony tint |

PI names and durations, including the 2027 sample with four development Sprints plus IP and quarter-style PI names, are examples rather than prescribed configuration.

### Capacity and activities

| Entity | Key fields / relationships | Invariants |
|---|---|---|
| Category | train, name (+ short label), colour, kind (development/overhead), default allocation % | Development categories including **Bugs** share post-overhead capacity; development allocation totals 100%. Show the full name where it could be confused with the Feature entity (e.g. "Feature development") |
| TeamCategoryAllocation | team, PI, category, override % or inherit | Unset inherits Train default, not zero; fixed for that PI |
| **OverheadReserve** (was Deduction) | member, iteration, overhead category (Training / General work), reserved hours, source (`pi_plan` \| `sprint_adjusted`) | Set per member per Sprint at **PI planning**, adjustable at Sprint Planning (changes that member's dev days). Deducted once from capacity; never SP, never velocity |
| **OverheadTicket** | team, iteration, overhead category, title, member, hours, optional scheduled date, notes | Draws against the member's reserve; reserve may stay partly **unticketed**. Tickets over reserve → plan-check warning. Dated tickets show as a "T" day on the calendar (not yet mocked) |
| UnplannedDeduction / activity | member(s), date, duration, category, optional note | Actual overhead time during a Sprint; no Project or Story parent |

Classification rule: work that changes the product is development work in SP (Tech debt / Enabler); learning, ritual or exploration is Training hours.

### Planning work and dependencies

| Entity | Key fields / relationships | Invariants |
|---|---|---|
| Project | train, name, colour, description | May span PIs and multiple Teams |
| Feature | **project**, **owning team**, **PI**, key, name, target, estimate revisions, colour | Single Team and PI; the feature span is derived from child Stories' Sprint slices. Ordering among features is by rank, not a priority field |
| Story | **project**, owning team, optional Feature, **optional PI** (none = unscheduled backlog), category, current SP, actual SP, designation (+ **stretch reason**), workflow state, **owner (required once in a Sprint)**, **statement** (`as_a`, `i_want`, `so_that`; full variant only), description, **target date**, optional **milestone link**, **blocked** (bool + reason), **removed reason/note** (when Removed), rank | Feature parent must have same Team and Project; all slices stay in Story PI. Choosing a Sprint sets the PI. A PI different from the Feature's PI is an advisory warning, not a block |
| Bug | **project**, owning team, optional Feature, optional PI, **Bugs category**, workflow state (bug flow), current/actual SP, designation, owner, **severity** (`S1` Critical \| `S2` Major \| `S3` Moderate \| `S4` Minor), **environment** (`production` \| `staging` \| `qa` \| `development`), **version** (text), **device_os** (text), **expected_result**, **actual_result**, description, target date, optional milestone link, blocked, removed reason/note, rank | Distinct work-item **type** and workflow. Shares planning fields, tasks, tags, dependencies, commitment trail and Removed/Delete with Story. No user story statement and **no AC list** (the expected result is the acceptance criterion). Severity is set at triage; **no priority field** |
| **ReproStep** | bug, order, text | Ordered "Steps to reproduce"; add, remove, reorder |
| StorySlice | story, iteration, planned point share, confirmed actual share | One per Sprint occupied; Stretch Σ shares = Story SP; **no cross-PI slices**. Carry-over is derived (previous slice not done) |
| Task | parent work item (Story/Bug as applicable), optional slice, **assignee** (defaults to the story owner), title, estimate hours, remaining hours, state | Created/refined at Sprint Planning; not on PI planning board. Assigning/dropping a story to a person sets the owner and, by default, all its tasks to that person |
| **Buffer** | team, iteration, category (type), title (default by type, e.g. "Bugfix buffer"), holder (member), SP, PI-planned SP | Placeholder SP for unknown work. Set at PI planning, revisited at Sprint Planning. Counts toward planned load; **outside the commitment**; unused SP released at Close Sprint, never in velocity |
| **BufferDraw** | buffer, work item, SP | Mid-Sprint item drawn from a buffer; its SP comes out of the buffer so load stays flat; overdraw → over-plan warning (flow not yet mocked) |
| **ChecklistItem** | work item, list (`ac` \| `dor` \| `dod`), text, **state** (`not_done` \| `done` \| `na`), order, `from_template` | Three-state; N/A excluded from counts. Which lists exist depends on the layout (below). Close check reads **AC (where present) + DoD** items still `not_done` (advisory) |
| **ChecklistTemplate** | team, list (`dor` \| `dod`), **applies_to** (`story_full` \| `story_light` \| `bug`), ordered item texts | Team defaults edited in Settings; copied into each new work item of that kind; items can be added per item. Light stories get no DoR template |
| **Tag** | name (unique, lower-case, hyphenated) | **Universal** across the app (all Trains/Teams), so tags filter and report across teams |
| **WorkItemTag** | work item, tag | Many-to-many |
| Dependency | `from_story`, `to_story`, note | **A → B means A is the predecessor and must be completed before B starts**. Cross Feature/Project/Team allowed; Stretch link applies to **whole Story**, not a slice. Planning-order violations are advisory warnings |
| ExternalDependency | description, external owner/team/department, expected availability/status, links to dependent internal work | Represents outside-ART/department prerequisites such as hardware rig delivery; **no fake internal Story**. Optional Dependencies board swimlane |
| Workflow / State | per work-item type, ordered states, typed `active/waiting/done`, optional WIP, `counts_as_completed` | **Story:** New → Active → Quality Check → Acceptance → Closed. **Bug:** Triage (waiting) → Investigating (active) → Correcting (active) → Verification (waiting) → Closed. Both have terminal **Removed** (done-type, `counts_as_completed = false`). Bug "Transferred" is *Move to team*, and "On hold" is the **Blocked** flag — neither is a state. StateChange is recorded for each transition |
| BoardInstance / BoardPlacement | view type, PI, Team/ART scope; placed work item / coords | View-specific positioning only, independent of scheduling and capacity; owned Features appear only under their Team on ART board |

The terms `from_story` and `to_story` are taken from the existing handoff for internal Story links. If Bug predecessors or external predecessors need richer relationship typing, finalize the physical schema in the dependency feature; do not reverse the directed semantics.

### Work item layouts (type × category)

| Layout | Applies to | Main content | Checklists | Close button |
|---|---|---|---|---|
| **Full story** (5w) | Story, category **Feature development** | User story statement, description | AC · DoR · DoD | Close story |
| **Light story** (5w-l) | Story, any other development category (**Enabler, Estimation, Tech debt**) | Description | AC · DoD | Close enabler / estimation / tech debt |
| **Bug** (5w-b) | Bug | Environment, steps to reproduce, expected / actual result, description; **Severity** in the header | DoR · DoD | Close bug |

- The layout is **derived** (type + category), not stored. Changing a Story's category between Feature development and the others switches the layout; statement and DoR items are **kept but hidden**, never deleted.
- "Change type" (Story ↔ Bug) remains a real action because Bug is a separate type; converting keeps shared fields and hides type-specific ones.
- Everything else (header, planning column, tasks, dependencies, commitment trail, discussion, history, Removed/Delete) is shared.

**Removed vs Delete:** *Removed* keeps the item and its history, takes it out of plans/boards (hidden by default, "Show removed" filter), velocity, throughput and **say/do**, and requires a reason + optional note. Reasons — **Story:** Not needed anymore / Duplicate of another item / Superseded by another item / Moved out of scope by the PO. **Bug:** Not reproducible / Duplicate of another bug / Works as designed / Won't fix / Not needed anymore. *Delete* is only for items created by mistake.

**Derived, not stored:** aging (time in current state, from StateChange; amber ≥ 3 d, red ≥ 5 d), missed target (today > target and state before Acceptance / Verification), carry-over, "target after milestone" plan-check, work item layout.

### PI planning artifacts

| Entity | Fields | Rule |
|---|---|---|
| PIObjective | team, PI, text, committed boolean, planned BV, actual BV, score owner, links to Features | Objective commitment is independent from Story designations |
| Risk | team, PI, text, ROAM, owner | |
| ConfidenceVote | team or train, PI, 1–5 counts | |

(Milestone moved to *Organisation and calendar* as a team-level entity; ART-board milestones reuse it with `scope = train` later.)

## 3. Plan versions vs. commitments vs. Actuals

**These are three different domain functions.** All may use a common physical snapshot mechanism, but they must be distinguishable for business logic, audit and UI.

| Concept | User-facing event | Captures |
|---|---|---|
| **PlanVersion** | User intentionally saves **v1**, **v2**, **v3**, etc. | **Complete current PI planning state**, including unchanged planning records from prior version, plus revisions. v3 can be a mid-PI replan; earlier versions are retained. Not an official commitment |
| **PICommitment** | **Start PI** — Admin/RTE | The current PI Plans for all participating Teams become the official PI Commitments, including **capacity totals per member × Sprint**, overhead reserves and buffers. This is not a manual "Baseline the PI" action |
| **SprintCommitment** | **Start Sprint** — responsible SM | The **current Sprint Plan** that SM has just reviewed and confirmed, including **capacity totals per member**, **velocity value and source** (rolling / PI override / Sprint override), forecast SP, **planning style**, buffers and overhead reserves. Can be recorded retroactively, but never silently reconstruct an earlier plan |
| **SprintClosure / Actuals** | **Close Sprint** — SM | Confirmed final actual Story/slice SP, actual capacity and other Sprint outcomes; released buffer SP; items **removed after commitment** shown for information only (they never count in say/do) |
| **StateChange** | Every work-item transition | Immutable item/from/to/when/by record, independent of plan snapshots |

Commitments store **totals only** (integer minutes for capacity), are immutable, and plan versions never overwrite them.

### Three-level history (commitment trail)

`PI Commitment → Sprint Commitment → Actuals`, plus **Current** as a live, mutable field. It supports Story/Slice, Feature roll-ups and capacity queries without extra user-edited PI/Sprint points fields. A Removed item's trail ends in **Removed** instead of an Actual.

Example: Story `PAY-439` shows **PI 3 → Sprint 5 → Actual 5**. An item added after PI start has no PI Commitment entry (e.g. Bug `PAY-D97`: "Not in PI plan" → Sprint 3 SP). A stretch may have several Sprint Commitment slice entries, one per Sprint it occupies. A plan version v3 **does not override** the PI or Sprint Commitment references; a Sprint started after v3 can, of course, commit the then-current Sprint Plan.

### Start/Close Sprint dates and trust-based review

Store separately:

1. **Scheduled Sprint start/end dates** for that Team (from ART cadence + allowed one-working-day offset).
2. SM-selected **effective start/close date** through **Start Sprint** / **Close Sprint** date pickers.
3. **Action timestamp** recording when the SM actually confirmed in Azusa.

This permits clerical late starts, early closure when Review/Retro moves ahead of holidays on the last two scheduled days, or closure on next Sprint Day 1 **without changing the scheduled end date**.

**Start Sprint review** must show current Story count, committed/SP scope, Stretch allocations, buffers, forecast capacity, load, dependencies and warnings. Warnings are advisory. **Commit what the SM reviews now**, not a reconstructed plan from the selected earlier effective date.

Operator example: Monday originally 40 SP, Tuesday changed to 48 SP, Wednesday SM backdates Start Sprint to Monday after reviewing the current plan → **48 SP official Sprint Commitment**, with the Monday effective date and Wednesday action timestamp separately preserved. Subsequent changes never rewrite that commitment.

**Close Sprint** reviews prefilled Actuals and confirms them. Preserve prior StateChange and planning events independently. Audit supports trustworthy planned-versus-actual reporting.

### Storage direction

Recommended normalized snapshot/read-model concepts (not finalized physical tables):

- Full PI planning snapshots: `plan_version` and queryable version entries containing relevant plan entities/relationships, dependencies, capacity assumptions/allocations, objectives, risks, milestones and layout.
- Official event records: `pi_commitment`, `sprint_commitment`, `sprint_closure`, linked to the relevant immutable commitment state and event timestamps/effective dates.
- Execution: current work-item tables, `state_change`, actual Story/Slice values, actual capacity deductions and audit records.
- `plan_trail` read model: PI Commitment, Sprint Commitment, Actual and Current per work item/slice; comparisons can also choose an arbitrary **Plan Version**, explicitly labeled as such.

Do not present an unrequested alternative snapshot-scope architecture decision as unresolved: **the operator has already confirmed full planning version snapshots and independent lifecycle commitments**.

## 4. Capacity formula

**PI level:** days. **Sprint Planning:** hours. **Story Points are never converted directly to hours** — with one stated, display-only exception below. Normalized velocity (SP/dev day) bridges points and time. Track canonical durations in integer minutes when feasible; present days/hours according to context. **Workday = 8.0 h** (team setting) is the only hours↔days factor; there is no separate focus factor.

Per capacity-contributing member `m`, Team Sprint `i`:

```text
working_days(m,i)    = NETWORKDAYS(team_scheduled_start(i), team_scheduled_end(i), holidays(location(m)))
available_days(m,i)  = working_days(m,i) − Σ active absences affecting capacity
planned_overhead(m,i)= Σ overhead reserves (Training, General work) + ceremonies + meetings attended
                       (days at PI level; hours at Sprint Planning)
dev_days(m,i)        = fte_factor(m) × (available_days(m,i) − planned_overhead(m,i)) + planned overtime

team_dev_days(i)     = Σ dev_days(m,i)              # exclude PO and SM
velocity(i)          = sprint override ?? PI override ?? rolling normalized velocity
forecast_sp(i)       = team_dev_days(i) × velocity(i)
category_budget(c,i) = forecast_sp(i) × development_category_pct(c)
planned_sp(i)        = Σ planned slice SP (committed + stretch) + Σ buffer SP
load(i)              = planned_sp(i) ÷ forecast_sp(i)        # 85–115 % on target
```

Per-person load depends on the Sprint's **planning style**:

```text
Owner model:        load(m,i) = (Σ SP of stories owned by m + buffer SP held by m) ÷ (dev_days(m,i) × velocity(i))
Distributed model:  load(m,i) = (Σ task hours assigned to m + buffer SP held by m × hours_per_sp(i)) ÷ dev_hours(m,i)
                    hours_per_sp(i) = team_dev_hours(i) ÷ forecast_sp(i)
```

- **Exception (display only):** in the Distributed model a buffer's SP is shown on its holder's hours ring via `hours_per_sp`. This is not stored and never feeds velocity or capacity; operator decision 2026-11-20.
- In the Distributed model, Sprint backlog stories must be tasked; an untasked story is a plan-check warning (its SP is on nobody's load).
- Team deduction mode: percentage of available days or fixed days per member/Sprint; defaults can be refined to ceremonies and additional meeting hours at Sprint Planning.
- `fte_factor` handles part-timers and new joiners; default 8 hours/day with Team override. Location-specific holidays and absences apply per member; staggered Team scheduled dates drive each Team's working-day window.
- Overhead-category time is **deducted once**. Training/Retro are not Stories and never receive velocity credit. Buffers count in load but never in velocity.
- Normalized velocity = `Σ completed development SP ÷ Σ actual development days` for the last four completed Sprints (a ratio of sums, not average of sprint ratios). Use available history, falling back to manual seed if none.
- Development category allocations total 100%, with Team-specific overrides inheriting the Train's defaults when unset; preserve committed allocation history. In category views, a buffer counts inside its own category.
- Existing sample/golden cases from the original handoff, including Palawan 291.25 dev days × 0.92 SP/day ≈ 268 SP, remain **illustrative test fixtures for that configured sample cadence**, not globally valid fixed-date rules. Rebuild from a single canonical seed dataset where prototype screenshots disagree.

## 5. Metrics, views and traceability

| Metric | Source |
|---|---|
| Planned vs actual capacity | PI/Sprint **Commitment** capacities vs finalized Actuals, compared at matching planning level |
| Velocity | Actual point-bearing development work completed in Sprint; Story stretch-slice actual points confirmed at Sprint close. Excludes buffers (unused SP) and **Removed** items. Bug counting/point conventions must be clarified in work-item/metrics feature rather than silently excluded |
| Say/do | Committed items only; stretch, buffers and **Removed** items are excluded entirely (removed items never count against say/do, even if removed after Start Sprint) |
| Normalized velocity | Four-completed-Sprint rolling ratio of sums (SP / actual dev day) |
| Throughput | Number of work items reaching Done (Closed), counted once, by type/category; Removed not counted |
| Sprint predictability | **Formula deferred** to operator during M3; must read Sprint Commitment, not latest Plan Version |
| PI predictability | Actual BV relative to planned BV on committed PI objectives (stretch business objectives as in original handoff) |
| Flow efficiency | Active-state time / total cycle time; later confirm state typing and thresholds |
| Later: bug metrics | Open bugs by **severity**, time to fix by severity, reopen rate, escape rate by environment (severity and environment now captured) |

**Board ownership and placement:** Team PI board is Project × Iteration; ART Program Board is Team × Iteration; features stay in their owning Team row. Positions are freehand and view-scoped, while Sprint allocation comes from slices. Internal predecessor edges can cross Teams/Projects, and ExternalDependency records can be displayed in a dedicated Dependencies swimlane. Stretch cards can span columns only **within their PI**. Board warnings are advisory, not blockers.

## 6. Milestone implications

- **M0 Calendar/People/Capacity:** configure variable ART cadence/custom Sprint names, Team one-working-day lead/lag, per-location holidays, dated ceremonies/meetings, team milestones, overhead reserves, and non-story overhead activities. Keep provenance and role placeholders (Admin/RTE/SM/PO) even before RBAC enforcement.
- **M1 Team PI Planning:** separate Story vs Bug types; Project-parented Stories and Bugs; single-Team Features; one-PI constraints; directed cross-Team/Project and external dependencies; buffers and overhead reserves per Sprint; full Plan Versions and **Start PI → PI Commitments**.
- **M2 Sprint Execution:** Sprint Planning (planning style, velocity override, buffers, overhead tickets); **Start Sprint** review + date picker + commit current plan; **Close Sprint** date picker + confirm Actuals; action timestamps separate from effective and scheduled dates. Work item view in three layouts (full story, light story, bug): statement, bug report fields + severity, AC/DoR/DoD checklists with per-kind templates, tags, tasks, Removed state, workflows and state history.
- **M3 Metrics:** query `PI Commitment → Sprint Commitment → Actual` and version comparisons without mixing them; operator supplies sprint predictability formula.
- **M4 ART Board:** one Team row per owning Feature; common ART iteration identity with allowed Team offset; cross-Team and outside-ART dependency visualization; train-scope milestones.

**No further blocking architecture questions.** Defer remaining UI/chart/holiday/state-typing and precise schema details to the respective SDD feature work, without revisiting these settled requirements.
