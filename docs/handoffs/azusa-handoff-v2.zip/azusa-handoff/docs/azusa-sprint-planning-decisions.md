# Azusa — Sprint planning & backlog decisions (2026-11-18, updated 2026-11-20)

Decisions settled on the hi-fi canvas (boards 5, 5b, 5p, 3b/3c/3d). Carry these into the handoff doc and the Settings screen. Consistent with `azusa-data-model.md` §3 (PI Commitment / Sprint Commitment / Actuals).

## Settings to add (Team settings)
- **Planning style**: `Owner model` | `Distributed model` (team default; see "Distributed model" below for the 5p behaviour).
  - Owner: an item's SP counts toward its story owner. Per-person check = assigned SP vs person forecast SP (dev days × normalized velocity).
  - Distributed: per-person load = task hours by task assignee (+ buffers converted to hours) vs dev hours (dev days × workday hours). SP stays team-level.
  - Style is **snapshotted into the sprint commitment** (Start Sprint); set per team in Settings, locked once the sprint starts. Past sprints keep their style. On 5p the style is shown as an **info pill** (no switch on the page).
  - Data model: always store both story owner and per-task assignee (task assignee defaults to story owner). Style only changes which one buckets aggregate — switching never loses data.
- **Board quick settings** (Iteration board modal: swimlanes, show sprint goal) must also live in Settings; the modal is a shortcut.
- **Velocity per sprint**: defaults to the rolling normalized velocity (or the PI-planning override, if the PI used one); the team can set a sprint-specific override. Snapshotted with the sprint commitment at Start Sprint.
- **Workday hours**: 8.0 (team setting; possibly per location later). This is the only hours↔days factor. There is **no separate 6 h "effective hours" factor** — an earlier prototype value of 6.0 was an assumption and has been removed; overheads are already subtracted on the calendar, so a focus factor would double-count them.
- Ceremonies are **not on fixed sprint days** (planning isn't necessarily at the sprint ends) — no auto-template; ceremonies are entered per sprint with dates. (Prototype demo data: planning day 1, refinement each mid-sprint Friday, review + retro on the last day.)
- Future enhancement: **Definition of Ready** flag on backlog items (often not observed; not in v1).

## Capacity
- **Keep it simple: the team calendar is the single source of truth for leave.** Leave is always a dated entry. When someone only says "reserve a day this sprint", park it on a placeholder date (e.g. day 2) and move it at sprint planning if needed. No floating/undated leave, no tracking of date moves — only the capacity totals matter.
- Capacity is always **derived from the calendar as it stands** (pure function of absences, holidays, ceremonies, meetings, deductions). Moving a leave day onto a ceremony/meeting day naturally removes that person's deduction for it.
- **Boundaries = existing lifecycle events** (no new "lock" concept):
  - **Start PI** (Admin/RTE) → PI commitment includes capacity totals per member × sprint.
  - **Start Sprint** (SM) → sprint commitment includes capacity totals per member for that sprint, plus the velocity value/source and forecast SP.
  - Commitments are immutable; plan versions (v1/v2/v3) never overwrite them. Totals only, in integer minutes; no per-change audit trail.
- Team calendar shows commitment status chips ("PI committed", "Sprint committed" — date in the tooltip only; amber "PI not started · capacity is live" before) and **vs PI** / **vs Sprint** columns = live − committed total, shown only once the respective commitment exists. Member added after a commitment → no line → shown as new.
- **Sprint capacity lives on the Team calendar** (boards 3b / 3c / 3d = 2-, 3-, 4-week sprints, all on the same design), not a separate screen (the standalone "3s Sprint capacity" mock was dropped):
  - View switch `Days off | Dev hours`, inside the calendar panel, followed by the instructions ("Click a person's day to log leave… Click a date to add a milestone…") and the commitment chips. Dev hours cell = workday (8 h × FTE) − stand-up − that day's ceremonies and the meetings that person attends; leave/holiday = 0; half day = half; planned overtime +2 h. Cells are scheduled hours (no focus factor).
  - Per-person total (dev h) column, vs PI / vs Sprint columns, and a Team per-day row.
  - Four tables under the grid, **50/50 in two rows**: Holidays + Milestones, then Scrum ceremonies + Meetings. Holidays (date, holiday, location, dev days lost); Milestones (date, name, ✕ remove; "+ Add"); Scrum ceremonies (date, duration; whole team); Meetings (date, who — whole team or specific people, duration). Ceremony/meeting rows drive both the cell hours and the date-header highlights.
  - 2- and 3-week sprints use the normal layout; 4-week sprints use compact name/total columns to fit 1440 px. Fallback if tight: collapse weekends to a 6 px divider.
  - Header links: Sprint planning, Capacity planner.
- **Hours → SP bridge lives on Sprint planning (5p)**, in the Team capacity card (see Views). Changing velocity re-forecasts the team and every person.
- Team plans in **SP**: forecast SP = dev days × normalized velocity.

## Overhead (Training, General work) — decided 2026-11-19
- Overhead categories are planned in **hours, not SP**; excluded from velocity, the gauge and the portrait rings (their cost is already out of capacity).
- **Reserve + tickets model**: PI planning reserves overhead per person per sprint (not fixed — set at PI planning, e.g. Training 4–8 h, General work 8–16 h). At sprint planning the reserve can be adjusted per person (changes that person's dev days → forecast → ring). Tickets draw against the reserve.
- **Training** (improvement, innovation, retro experiments, courses) should have tickets with hours. **General work** (support rota, admin, ad-hoc) may or may not have tickets — unticketed reserve is shown as such.
- Classification rule: changes the product → development work in SP (Tech debt / Enabler); learning, ritual or exploration → Training hours.
- Tickets over reserve → plan-check warning (red meter; per-person red input + "Tickets exceed reserve" in the reserve modal). Resolution: drop a ticket or raise that person's reserve.
- 5p UI: collapsible **Overhead** group at the bottom of the Sprint backlog (summary when collapsed: "Training 22 / 40 h · General work 16 / 72 h"); per category a budget meter, ticket rows (hours, person, ↗ details), an italic "Unticketed reserve" line, and an inline "+ Add training / general work ticket" row (title, hours, person). "Edit reserve" opens a **modal** (per-person Training h / General work h, team totals, live dev capacity + forecast). Overhead ticket details panel: title, person (with their reserve), hours, optional scheduled date (dated → "T" day on the team calendar; undated → reserve only), notes, remove from sprint. Dev capacity tooltip breaks down available − leave − general work − training.
- Not yet mocked: overhead tickets in the Backlog panel (shown in hours, drop into Overhead), "T" cells on the calendar.

## Buffers — decided 2026-11-19
- A **buffer is SP held inside the forecast for work that isn't known yet** (unlike overhead, which is hours taken out of capacity). Modelled as a placeholder work item with SP, a holder and a **type = work category** (dropdown shows plain category names).
- Typical use is bugs, but not only: **support work counts as SW maintenance** (it's maintenance), so bug and support buffers are both SW maint. Default titles by type: SW → "Bugfix buffer" (renamable, e.g. "Support buffer"), FD → "Feature buffer", EN → "Enabler buffer", TD → "Tech debt buffer", ES → "Estimation buffer".
- **Set at PI planning** per sprint (holders assigned freely), **revisited at sprint planning**: holder, SP and type editable; rows show "Planned at PI planning" or, in orange, "PI plan x SP · changed this sprint" / "Added this sprint". Start Sprint creates the buffer rows from the PI plan.
- **Counts as planned load** (gauge, team total, holder's ring; the portrait tooltip says how much is buffer). In the Distributed model a buffer is **converted to hours on the holder's ring** at the team's dev hours per SP. **Outside the commitment**: excluded from say/do; unused SP is released at sprint close and not counted in velocity. Items drawn from it count as delivered work like any other item.
- **Draws (mid-sprint, Iteration board — not yet mocked)**: add a bug/urgent ask with "Draw from buffer" → its SP comes out of the buffer, total load stays flat; a draw larger than what's left triggers the over-plan flag.
- Visual language: **hatched bar in the category colour** (bugfix buffer = red hatch). Commit column shows a dashed grey hexagon ("outside the commitment"), no toggle.
- 5p UI: collapsible **Buffer** group at the bottom of the Sprint backlog, above Overhead (reserves together at the bottom; carry-overs → ranked work stays continuous on top). Header: total SP + "as PI plan" or orange "PI plan x SP". Inline "+ Add buffer" row (type, SP, holder). Details panel: type, holder (with load), SP, PI plan value, Draws, close-out rule, remove.
- Gauge: *Commitment* view → own grey-hatched **Buffer** segment (committed / stretch / buffer). *Category* view → buffer **counts inside its category**, drawn as a hatched continuation of that category's segment (SW maint. 3 SP items + 4 SP buffer = 7 SP; legend row hover shows the split). *Category vs PI plan* → same solid + hatched bar; PI plan per category includes buffers; key row adds a hatched "Buffer" swatch.
- The old "Bug budget (triage)" work item is replaced by buffers.

## Milestones (special dates) — decided 2026-11-20
- One generic type: **Milestone** (date + name). Releases, code freezes, demos etc. are just named milestones for now.
- **Team-level**, entered by the SM / PO on the **Team calendar** (not on 5p). No ART-level inheritance for now. Milestones don't affect capacity (if a release day ties people up, log it as a meeting/overtime).
- Calendar: **click a working date in the header** → modal. Empty date → "Add milestone" (date + name). Date with milestones → "Milestones" modal: each existing one editable inline with a grey ✕ to remove, "Add another" field, Done. "+ Add" on the Milestones table opens the same modal with a date dropdown. Header tooltip names the date's milestone(s) and ceremonies.
- **Colour: solid red (#FF0000, white text) date header — the calendar key's Milestone swatch — on both the Team calendar and the 5p calendar preview. No diamond. Milestone takes precedence over the scrum-event tint** (a refinement Friday with a milestone shows red).
- **Planning flag**: an item may optionally link to a milestone (item details → "Milestone (optional)"). Linking an item with no target date sets its target to the milestone date. If the item's **target is after its milestone** → amber **plan-check warning triangle** after the title (tooltip "Target Feb 24 is after milestone Release 27.2 code freeze (Feb 23)"), also shown under the dropdown in details. Unlinked items are never flagged. (Warning triangle = plan-check, distinct from the missed-target flag, which means the date has actually passed.)

## Distributed model on 5p — decided 2026-11-20
- **SP stays team-level** (capacity card, gauge, velocity, forecast unchanged). Per-person load = **hours of tasks assigned to them + their buffers × team dev hours per SP** vs their dev hours (overhead is already out of dev hours).
- **Story owner is still required.** Dropping an item on a portrait (or picking an owner) makes that person the owner and **assigns all of the item's tasks to them by default**; individual tasks can then be reassigned in item details (per-task assignee dropdown, owner marked "(owner)").
- **Sprint backlog items must be tasked**; Backlog items may not be yet. An untasked Sprint backlog item gets the plan-check triangle ("No tasks yet: 5 SP isn't on anyone's load"); details explain that only task hours count in this model.
- 5p UI in Distributed model:
  - Team strip rings in **hours** ("54 / 60 h"), same 85–115% bands, over badge "+n h"; tooltip breaks down tasks + buffer hours and items owned. Header: "45 / 52 SP · 87%" plus "334 / 448 h tasked". Hint: "Drop an item on a person to make them owner; its tasks go to them too." Planning style shown as an info pill ("Distributed model" + ⓘ), not a switch.
  - Sprint backlog owner column (64 px) = **avatar stack**: owner first, then other task assignees (max 2 + "+n"); hover lists owner and others.
  - Each row's sub-line shows the **task count** after the feature: "F-119 One-page checkout · 6 tasks" (no icon; feature truncates first, full name on hover; "No tasks" in amber when empty; hover shows task hours).

## Load thresholds
- Team and per-person: <85% under (orange), **85–115% on target (green)**, >115% over (red). Per person, under is neutral.

## Commitment
- **Stretch counts inside the forecast** (planned but not committed due to dependencies/unknowns). Planned = committed + stretch + buffer. Stretch requires a reason. Say/do counts committed only.
- Row icons: **committed = green hexagon with white ✓**; **stretch = yellow (#F2C230) hexagon with ink ~**; buffer = dashed grey hexagon (no toggle). Click toggles committed/stretch (stretch should require a reason — reason popover proposed, not yet mocked).
- **Carry-over items always sort to the top of the Sprint backlog**, with a light amber row tint (#FBF1DF) + "Carried over from Sprint N" tooltip/label. No pill.

## Flags
- **Aging** (time in column) and **missed target date** are separate signals.
- Target date is **met when the item reaches Acceptance**. Missed = today > target and item in New/Active/Quality Check.
- Blocked = red no-entry hexagon; aging = clock hexagon (amber ≥3d, red ≥5d on rows; single amber icon in summaries); missed target = red hexagon with white flag + date. **Warning triangle is reserved for plan-check warnings** (target after milestone; no tasks in Distributed model). (Live Iteration board still shows the old calendar glyph for missed target — swap to the flag.)
- Inline flags on list rows sit after the title in fixed order missed → aging → blocked → plan-check; they never shrink — the title truncates (full title on hover).

## Views
- **Team backlog (5b)**: one PO-ranked list, Jira-style sections: current sprint (with sprint goal + flag counters) → upcoming sprints → Backlog. Move via ⋯ menu or drag. Breadcrumb: ART › Team (no PI/sprint).
- **Sprint planning (5p)** — final layout (iterated via 5p-B → H; the sprint-line layout, sections-only variant and side bucket column were dropped). The canvas board now demonstrates the Distributed model; Owner model differs only as noted above. Entered from the backlog (Plan sprint icon on the next upcoming sprint), not a mode on the Iteration board. Top to bottom:
  1. Header: Team calendar link, + Work item (white on ink), Start sprint (ink on amber).
  2. Sprint goal card: header line, then goal (or italic "None defined yet."), Write/Edit action.
  3. Row split 2/3 + 1/3:
     - **Team calendar preview**: nickname × working day grid with leave codes; date header red for milestones (precedence) or light orange for scrum events (hover names them); CAP column (dev days) and Team total; "Edit in team calendar →" (milestones are edited there, not here). Fits 4-week sprints in the 2/3 width.
     - **Team capacity card**: Dev capacity (d, with breakdown tooltip), Velocity (value + ✎ edit; override in orange with ↺ reset), Forecast (SP, ⓘ tooltip) — right-aligned, regular figures. Plan view dropdown: *Commitment* (gauge committed/stretch/buffer) · *Category* (gauge by category, PI brief colours) · *Category vs PI plan* (bullet chart, bar per category + ink PI tick, total on key row). Gauge centre = planned SP + "Planned SP" + % pill in band colour; gauge scales 150–210 px.
  4. **Team strip** (sticky): one portrait per person with a load ring (Owner model: SP vs forecast SP; Distributed model: hours vs dev hours; orange under / green 85–115 / solid red + over badge), nickname, value. Header shows team total "45 / 52 SP · 87%" (+ tasked hours in Distributed) + planning-style info pill. Portraits spread evenly; ≥16 people (1440 px fits 15) → horizontal scroll with ‹ › chevrons. Drop an item on a portrait = make owner (and load it if it came from the Backlog).
  5. **Workspace, 50/50**: Backlog (left) » Sprint backlog (right), separated by an amber dashed divider with an ink-on-amber » badge. Both are fixed-height panels (in-app: viewport − strip) that scroll internally; column headers pin inside the scroll area.
     - Backlog: search (ID/title) + category dropdown; grouped by **upcoming PI sprints in order, then unscheduled Backlog** (group header: name left, "n items · x SP" right; collapsible; 8 rows then "Show N more"). Columns: ID, item (+flags), size (centred), » add button. No rank number shown (rank kept internally). No PI plan column (grouping replaces it).
     - Sprint backlog: carry-overs first, then rank order; Buffer group, then Overhead group at the bottom. Columns: ID, item (+flags; sub-line feature · task count), size (centred), owner (single avatar in Owner model, avatar stack in Distributed; unassigned = grey dashed "+"), commit icon, details. No SP total / split in its header (the gauge and strip carry it).
     - Drag: Backlog → Sprint backlog loads; Sprint backlog → Backlog removes; onto a portrait makes owner.
  - Item detail panel: owner, target date, milestone (optional), commitment + reason, tasks with hours (+ per-task assignee in Distributed).
- Iteration board links back to the backlog.
- Implementation note: in this canvas runtime, data bindings inside SVG `<text>` don't render; overlay HTML for dynamic gauge labels.

## Open (next)
All four planning questions are settled (training/overhead, buffers, milestones, Distributed model). Still to mock: buffer draw flow on the Iteration board; stretch reason popover; overhead tickets in the Backlog panel and "T" days on the calendar; missed-target flag glyph on the live Iteration board.
