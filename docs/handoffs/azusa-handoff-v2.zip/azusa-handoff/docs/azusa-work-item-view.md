# Azusa — Work item view decisions (2026-11-20)

Settled on the hi-fi canvas: **5w · Work item (page)**, **5w-m · Work item (modal)**, **5w-b · Bug (page)** and **5w-l · Enabler / Estimation / Tech debt (page)**. Sample items: PAY-439 "Default card selection" (Story), PAY-D97 "Saved-card list flickers on Android" (Bug), PAY-460 "Card updater webhook" (Enabler), all in current Sprint 2706. Complements `azusa-sprint-planning-decisions.md` and `azusa-data-model.md` (v0.6 covers the entities below).

## Two containers, one layout
- **Page** (deep link, shareable) and **modal** (opened from any board/list, keeps context) share the same layout. The modal is the page scaled down: max 1180 × 860 px over the dimmed source view; header block fixed, body scrolls inside the modal.
- Page breadcrumb stays **ART › Team** (no "Backlog", no item ID).
- Modal actions: Close story · Open as page (↗ expand icon) · Copy link · ⋯ · | ✕ Close. Page actions: Close story · Team backlog · Iteration board · Copy link · ⋯.
- Action buttons: only **Close story** carries a label (ink button, hexagon-check icon); the rest are 40 × 40 icon buttons (beige #F4F1EC fill inside the white card, 20 px icons from the icon set, tooltip + aria-label). Icons: `close-item`, `backlog`, `iteration`, `copy-link`, `more`, `expand`, `close` from the Kumiko set (all on board 8).
- Whole page is **one white card**; sections separated by whitespace, no inner cards. Body split **2/3 – 1/3** with a thin vertical rule.

## Three layouts by type and category
The layout is **derived** from the work item type and category, not chosen. Header, planning column, tasks, dependencies, commitment trail, discussion, history, Remove/Delete and three-state checklists are shared by all three.

| Layout | Board | Applies to | Main column | Checklist tabs | Primary button |
|---|---|---|---|---|---|
| **Full story** | 5w | Story · Feature development | User story → Description | AC · DoR · DoD | Close story |
| **Light story** | 5w-l | Story · Enabler, Estimation, Tech debt | Description | AC · DoD | Close enabler / estimation / tech debt |
| **Bug** | 5w-b | Bug (SW maintenance) | Environment → Steps to reproduce → Expected \| Actual → Description | DoR · DoD | Close bug |

- Changing a Story's category between Feature development and the others switches between full and light; the statement and DoR items are **hidden, not deleted**.
- **Change type** (⋯ menu, Story ↔ Bug) stays, because Bug is a separate type in the data model.
- Bugs have **no AC tab**: the expected result is the acceptance criterion. Close bug therefore checks only the DoD.
- Light stories have **no user story statement and no DoR**; AC stays so there is something concrete to verify.

## Header (fixed in modal)
- **Title block:** ticket ID as a mono eyebrow above the title; the **category colour bar** spans both lines on the left. No type word ("Story").
- **Status strip** (no dividers): State · Owner · Size · Sprint · Commitment · Flags. **Bugs add Severity after State.**
  - **Sprint** is the only placement control in the header: picker lists "No sprint" then sprints grouped by PI (with dates muted in the list only). **Picking a sprint sets the PI automatically.**
  - Flags: aging (amber/red clock hexagon), blocked; none for Closed/Removed items ("None").
- **Tags:** "TAGS:" label + pills with ✕, "+ Tag" adds inline (lower-cased, spaces → hyphens). Tags are **universal** across the app.
- Tabs: **Details · History** (underline style, amber active, no rule above).

## Pickers
- **No native selects on this page.** All dropdowns (State, Severity, Owner, Sprint, Feature, Category, PI, Milestone, Environment, new-task assignee) use one custom picker: white 14 px-radius panel, 36 px rows, leading dot/avatar/swatch where relevant, orange tint + ✓ on the current value, closes on pick, only one open at a time. Planning-column pickers keep a light 1 px border so they read as fields.

## Details tab — main column (full story)
1. **User story** — reads as three lines ("As a **…**, / I want to **…**, / so that **…**."); ✎ Edit swaps to three fields (As a / I want to / So that); Done swaps back.
2. **Description** — free text for context beyond the statement.
3. **Criteria tabs** (underline style, counts muted): **Acceptance criteria · Definition of Ready · Definition of Done**, e.g. "1/4 · 5/5 · 0/5" (N/A excluded from the count).
   - Every item is a **three-state checkbox**, click cycles **Not done → Done → N/A** (empty box / green ✓ / grey dash + struck text + "N/A").
   - DoR and DoD start from **team defaults (Settings)**; items can be added per item. → Settings needs a DoR/DoD template editor, with separate templates for full stories, light stories (DoD only) and bugs.
4. **Tasks** — "2 of 6 done · 22 h left of 44 h" + progress bar; rows: done checkbox, title, assignee (owner marked), estimate, left, state pill.
5. **Discussion** — comments + composer.
- **Adding items:** lists end with an orange "+ Add item" / "+ Add task" / "+ Add step"; the input only appears after clicking. Task composer = one bordered box: title on top; assignee pill, hours pill, Cancel, Add task (disabled until title + hours) below.

## Bug specifics (5w-b)
- **Environment** — read-only key/value block: Environment (Production / Staging / QA / Development), Version (e.g. "Android app 4.18.2 (build 4182)"), Device / OS (free text). ✎ Edit turns it into fields (Environment as a custom picker); Done returns to the read view.
- **Steps to reproduce** — numbered list (mono numbers in beige circles) with a step count; ✕ removes a step; "+ Add step" shows the next number as a dashed placeholder plus an input.
- **Expected result | Actual result** — side by side; green left bar on Expected, red left bar on Actual; each has its own ✎ Edit (textarea).
- **Description** — context such as the support ticket, impact and workarounds.
- **Severity** (status strip, after State) — square swatch + "S3 · Moderate"; picker rows show a short meaning:
  - **S1 · Critical** (red #D9443A) — outage, data loss, no workaround
  - **S2 · Major** (orange #E8890C) — key flow broken, poor workaround
  - **S3 · Moderate** (yellow #E9C46A) — works, but degraded
  - **S4 · Minor** (grey #A9ACB4) — cosmetic
  Set at triage; History records it ("set Severity · S3 · Moderate"). The bug DoR includes "Severity agreed with the PO".
- **No priority field.** The backlog rank is the priority; two priority systems drift apart.
- **Bug workflow:** Triage → Investigating → Correcting → Verification → Closed, plus Removed. Colours follow the story states by position (grey, blue, purple, amber, green). **Reopen** returns to Verification. "Transferred" is ⋯ → Move to team, and "On hold" is the Blocked switch; neither is a state.
- **Removed reasons for bugs:** Not reproducible · Duplicate of another bug · Works as designed · Won't fix · Not needed anymore.
- Bug DoR template (sample): Steps reproduce the issue · Environment and version recorded · Expected and actual result written · Severity agreed with the PO · Estimated by the team. Bug DoD (sample): Fix verified on the reported devices · Regression test added · Code reviewed and merged · Released or scheduled in a build · Support ticket updated.
- A bug picked from triage after PI planning shows **"Not in PI plan"** as its PI step in the commitment trail.
- ⋯ menu for bugs: Duplicate · Change type (Bug / Story) · Move to team… · Follow · Remove… · Delete (no Split).

## Light story specifics (5w-l)
- Main column: **Description** first, then **Acceptance criteria · Definition of Done**, Tasks, Discussion.
- Close button names the category: **Close enabler**, **Close estimation**, **Close tech debt**. Close check reads AC + DoD.
- The Category picker on this layout lists Enabler / Estimation / Tech debt; picking Feature development switches to the full layout.

## Details tab — right column
- **Planning:** Project · Feature (parent feature, swatch) · Category (full names here, e.g. "Feature development", to avoid clashing with the Feature field) · PI (2027.1 / 2027.2 / No PI (backlog)) · Sprint (same picker as header) · Story points · Commitment (Committed / Stretch; stretch reason field appears) · Target date · Milestone (optional; amber warning if target is after it).
- PI ≠ the parent feature's PI → amber warning "Feature F-112 is planned in PI 2027.1" (warns, doesn't block; data model ties a Feature to one PI).
- **Commitment trail:** PI → Sprint → Actual (Actual set at Close Sprint; shows orange "Current" if SP changed after commit; "Removed" when removed; "Not in PI plan" when added after Start PI).
- **Dependencies:** Predecessors / Successors / External, "+ Add link".
- **Status:** Blocked switch (reason field when on); status line ("In Active since Feb 5 · 3 days" / "Closed Feb 8" / "Removed Feb 8 · reason").
- Footer: created (bugs: "Reported") / last updated by and when.

## History tab
Timeline newest first: state changes, task updates, severity changes, linked milestone, Start Sprint / Start PI commitments, SP changes, creation.

## Closing, removing, deleting
- **Close story / Close bug / Close enabler…** (button, or State → Closed): checks **AC (where the layout has it) + DoD**; any item still *Not done* (N/A is fine) → dialog listing them with Cancel / "Close anyway" (advisory, like other plan checks). Actual SP is still confirmed at Close Sprint. When Closed the button becomes **Reopen** (stories → Acceptance, bugs → Verification).
- **New state: Removed** (terminal, done-type state; grey). Via State picker or ⋯ → "Remove…". Requires a reason + optional note. Story reasons: Not needed anymore / Duplicate of another item / Superseded by another item / Moved out of scope by the PO; bug reasons above. Keeps history; excluded from plan, boards (hidden by default, "Show removed" filter), velocity, throughput and **say/do — removed items never count against say/do, even if removed after Start Sprint** (operator decision 2026-11-20). Close Sprint may still show them for information. **Close button disappears** while Removed; the State picker can restore it.
- **Delete** (⋯, red) is only for items created by mistake.
- ⋯ menu (stories): Split (carry-over; to mock), Duplicate, Change type (Story / Bug), Move to team…, Follow, Remove…, Delete.

## Related 5p changes (supersede `azusa-sprint-planning-decisions.md` where they differ)
- 5p-I promoted: **Sprint backlog panel uses tabs** — Items · Buffer (SP) · Overhead (h, total reserve). Rows 48 px like the Backlog panel; **↗ details buttons removed — clicking a title opens details**.
- **Work item modal replaces 5p's item side panel** (operator decision 2026-11-20): clicking an item title in the Sprint backlog opens 5w-m. Buffers and overhead tickets keep their own small detail panels (they are not work items).
- **Team capacity card:** Plan view dropdown moved into the card header; Dev capacity · Velocity · Forecast in one row (values left-aligned under labels); gauge max height 260 px.

## Resolved in data model v0.6
Removed state (per-type reasons); DoR/DoD templates per work-item kind + three-state checklist items; universal Tags; team-level Milestones; buffer SP → hours recorded as a display-only exception; Bug fields (severity, environment, version, device/OS, repro steps, expected/actual); Bug workflow; derived layout; no priority field.

## Future enhancements
- **Queries (ADO-style)** — saved filters with macros (@Me, @CurrentSprint…); deferred. Search covers finding items for now. See `azusa-handoff-update-2026-11-20.md` §2.

## Open
- Severity on board cards (Iteration board, Team backlog) — proposed: small swatch for S1/S2 only; not decided.
- Modal (5w-m) versions of the bug and light layouts — same scale-down as the story; not mocked.
- "Feature" category short name vs Feature entity — consider renaming the category label app-wide (e.g. "Feature dev.").
- Still to mock: Split story flow.
