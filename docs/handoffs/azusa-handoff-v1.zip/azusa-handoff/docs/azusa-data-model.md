# Azusa — Data Model & Capacity Formula (v0.4)

**Status:** Operator-clarified conceptual data model · 2026-11-08. Updates v0.3 in the original handoff. This is **not** a finalized physical database schema. See `../AZUSA_HANDOFF.md` §§7–12, 20–21 for the detailed requirements and source decisions.

## 1. Scope, ownership and rules

- Team-level and Agile Release Train (ART)-level SAFe planning; personal, local-only project. No portfolio/large-solution layer for now.
- **Project** is long-lived; it can involve multiple Teams, derived from the Team ownership of its related work items. It has no own PI boundary.
- **Feature/Epic** (one entity with configurable display label) has a required Project, **one owning Team**, and **one PI**. Only Stories owned by that Team and Project may belong to the Feature. Legitimate work by another Team is split into its own Feature/Stories, linked with dependencies.
- **Story** has a required Project and owning Team; Feature is optional. Enablers and technical-debt work are Stories.
- **Bug** is a **separate work-item type** with a required Project and Team and is restricted to the **Bugs** work category. It is not modeled as a Story merely categorized as Bugs. The prototype uses the sample category name "SW maintenance (bugs)"; the real setup can use a Bugs label.
- **Training, Retrospective and General Work** activities are **non-story** capacity/activity entries; they require no Project and contribute **time deductions, not Story Points**. Do not count the same effort both as Story Points and overhead.
- A Feature, Story or Stretch slice **cannot cross a PI boundary**. A committed Story has one Sprint slice; Stretch Stories may have multiple Sprint slices **within one PI**.
- PI Objective committed/uncommitted is **independent** of Story committed/stretch/unplanned designation.

## 2. Conceptual entities

These names convey domain concepts; the implementer may normalize or combine tables as appropriate while maintaining the rules.

### Organisation and calendar

| Entity | Key fields / relationships | Invariants |
|---|---|---|
| Train (ART) | name, default work categories, calendar settings | Owns the PI/iteration cadence |
| Team | train, name, hours_per_day, deduction mode, `sprint_offset_workdays` | Shares ART iteration identities; offset is **−1, 0 or +1 working day** |
| Member | team, name, nickname, initials, role, `fte_factor`, location | PO/SM do not contribute development capacity; FTE handles part-timers/new joiners |
| User / Role | Admin, RTE, SM, Team member, tentative Business Owner | Single user now; RBAC enforced later. Preserve `created_by`, `updated_by`, timestamps |
| PI | train, name, configured start/end, lifecycle status | Admin/RTE configures PI boundaries and uses **Start PI** to establish all participating Team PI Commitments |
| Iteration (Sprint) | PI, name, scheduled start/end, kind (development/IP) | Admin/RTE controls count, length, dates and custom names; **YYWW is optional**, based on the ISO ending week |
| Team Sprint schedule | team, iteration, scheduled start/end or configured relative offset | Team-specific one-working-day stagger does not change ART iteration identity |
| Location | country, optional subdivision, time zone, calendar source | Member-based local holidays govern capacity |
| Holiday | location, date, portion, source, confirmed | Library seed + company/manual overrides |
| Absence / AbsenceType | member, date, portion, type, planned, active/cancelled; `affects_capacity` | Sick/annual leave reduce capacity; WFH/business trip may be attendance only |

PI names and durations, including the 2027 sample with four development Sprints plus IP and quarter-style PI names, are examples rather than prescribed configuration.

### Capacity and activities

| Entity | Key fields / relationships | Invariants |
|---|---|---|
| Category | train, name, colour, kind (development/overhead), default allocation % | Development categories including **Bugs** share post-overhead capacity; development allocation totals 100% |
| TeamCategoryAllocation | team, PI, category, override % or inherit | Unset inherits Train default, not zero; fixed for that PI |
| Deduction | member, iteration, overhead category, planned duration | General Work/Training/Retro as **time deductions**, not Stories |
| CeremonyTemplate | team, ceremony name, duration, frequency | Refines Sprint-level overhead hours |
| UnplannedDeduction / activity | member(s), date, duration, category, optional note | Actual overhead time during a Sprint; no Project or Story parent |

### Planning work and dependencies

| Entity | Key fields / relationships | Invariants |
|---|---|---|
| Project | train, name, colour, description | May span PIs and multiple Teams |
| Feature | **project**, **owning team**, **PI**, key, name, priority, target, estimate revisions, colour | Single Team and PI; the feature span is derived from child Stories' Sprint slices |
| Story | **project**, owning team, optional Feature, PI, category, current SP, actual SP, designation, workflow state, assignee | Feature parent must have same Team and Project; all slices stay in Story PI |
| Bug | **project**, owning team, PI, **Bugs category**, workflow state, relevant estimates / severity / priority | Distinct work-item **type** and workflow; detailed fields established in its feature spec |
| StorySlice | story, iteration, planned point share, confirmed actual share | One per Sprint occupied; Stretch Σ shares = Story SP; **no cross-PI slices** |
| Task | parent work item (Story/Bug as applicable), optional slice, member, estimate hours, remaining hours, state | Created/refined at Sprint Planning; not on PI planning board |
| Dependency | `from_story`, `to_story`, note | **A → B means A is the predecessor and must be completed before B starts**. Cross Feature/Project/Team allowed; Stretch link applies to **whole Story**, not a slice. Planning-order violations are advisory warnings |
| ExternalDependency | description, external owner/team/department, expected availability/status, links to dependent internal work | Represents outside-ART/department prerequisites such as hardware rig delivery; **no fake internal Story**. Optional Dependencies board swimlane |
| Workflow / State | per work-item type, ordered states, `active/waiting/done`, optional WIP | Story and Bug can use different workflows; StateChange is recorded for each transition |
| BoardInstance / BoardPlacement | view type, PI, Team/ART scope; placed work item / coords | View-specific positioning only, independent of scheduling and capacity; owned Features appear only under their Team on ART board |

The terms `from_story` and `to_story` are taken from the existing handoff for internal Story links. If Bug predecessors or external predecessors need richer relationship typing, finalize the physical schema in the dependency feature; do not reverse the directed semantics.

### PI planning artifacts

| Entity | Fields | Rule |
|---|---|---|
| PIObjective | team, PI, text, committed boolean, planned BV, actual BV, score owner, links to Features | Objective commitment is independent from Story designations |
| Risk | team, PI, text, ROAM, owner | |
| ConfidenceVote | team or train, PI, 1–5 counts | |
| Milestone | train, PI, iteration/date, name | Visible on ART board |

## 3. Plan versions vs. commitments vs. Actuals

**These are three different domain functions.** All may use a common physical snapshot mechanism, but they must be distinguishable for business logic, audit and UI.

| Concept | User-facing event | Captures |
|---|---|---|
| **PlanVersion** | User intentionally saves **v1**, **v2**, **v3**, etc. | **Complete current PI planning state**, including unchanged planning records from prior version, plus revisions. v3 can be a mid-PI replan; earlier versions are retained. Not an official commitment |
| **PICommitment** | **Start PI** — Admin/RTE | The current PI Plans for all participating Teams become the official PI Commitments. This is not a manual "Baseline the PI" action |
| **SprintCommitment** | **Start Sprint** — responsible SM | The **current Sprint Plan** that SM has just reviewed and confirmed. Can be recorded retroactively, but never silently reconstruct an earlier plan |
| **SprintClosure / Actuals** | **Close Sprint** — SM | Confirmed final actual Story/slice SP, actual capacity and other Sprint outcomes; actual work events are recorded during execution too |
| **StateChange** | Every work-item transition | Immutable item/from/to/when/by record, independent of plan snapshots |

### Three-level history (commitment trail)

`PI Commitment → Sprint Commitment → Actuals`, plus **Current** as a live, mutable field. It supports Story/Slice, Feature roll-ups and capacity queries without extra user-edited PI/Sprint points fields.

Example: Story `PAY-439` shows **PI 3 → Sprint 5 → Actual 5**. An item added after PI start has no PI Commitment entry. A stretch may have several Sprint Commitment slice entries, one per Sprint it occupies. A plan version v3 **does not override** the PI or Sprint Commitment references; a Sprint started after v3 can, of course, commit the then-current Sprint Plan.

### Start/Close Sprint dates and trust-based review

Store separately:

1. **Scheduled Sprint start/end dates** for that Team (from ART cadence + allowed one-working-day offset).
2. SM-selected **effective start/close date** through **Start Sprint** / **Close Sprint** date pickers.
3. **Action timestamp** recording when the SM actually confirmed in Azusa.

This permits clerical late starts, early closure when Review/Retro moves ahead of holidays on the last two scheduled days, or closure on next Sprint Day 1 **without changing the scheduled end date**.

**Start Sprint review** must show current Story count, committed/SP scope, Stretch allocations, forecast capacity, load, dependencies and warnings. Warnings are advisory. **Commit what the SM reviews now**, not a reconstructed plan from the selected earlier effective date.

Operator example: Monday originally 40 SP, Tuesday changed to 48 SP, Wednesday SM backdates Start Sprint to Monday after reviewing the current plan → **48 SP official Sprint Commitment**, with the Monday effective date and Wednesday action timestamp separately preserved. Subsequent changes never rewrite that commitment.

**Close Sprint** reviews prefilled Actuals and confirms them. Preserve prior StateChange and planning events independently. Audit supports trustworthy planned-versus-actual reporting.

### Storage direction

Recommended normalized snapshot/read-model concepts (not finalized physical tables):

- Full PI planning snapshots: `plan_version` and queryable version entries containing relevant plan entities/relationships, dependencies, capacity assumptions/allocations, objectives, risks, milestones and layout.
- Official event records: `pi_commitment`, `sprint_commitment`, `sprint_closure`, linked to the relevant immutable commitment state and event timestamps/effective dates.
- Execution: current work-item tables, `state_change`, actual Story/Slice values, actual capacity deductions and audit records.
- `plan_trail` read model: PI Commitment, Sprint Commitment, Actual and Current per work item/slice; comparisons can also choose an arbitrary **Plan Version**, explicitly labeled as such.

Do not present an unrequested alternative snapshot-scope architecture decision as unresolved: **the operator has already confirmed full planning version snapshots and independent lifecycle commitments**.

## 4. Capacity formula

**PI level:** days. **Sprint Planning:** hours. **Story Points are never converted directly to hours.** Normalized velocity (SP/dev day) bridges points and time. Track canonical durations in integer minutes when feasible; present days/hours according to context.

Per capacity-contributing member `m`, Team Sprint `i`:

```text
working_days(m,i)    = NETWORKDAYS(team_scheduled_start(i), team_scheduled_end(i), holidays(location(m)))
available_days(m,i)  = working_days(m,i) − Σ active absences affecting capacity
planned_overhead(m,i)= Σ planned GW/Training/Retro/meeting deductions (days at PI level)
                       (Sprint Planning refines overhead using ceremony/meeting hours)
dev_days(m,i)        = fte_factor(m) × (available_days(m,i) − planned_overhead(m,i))

team_dev_days(i)     = Σ dev_days(m,i)              # exclude PO and SM
forecast_sp(i)       = team_dev_days(i) × normalized_velocity(team)
category_budget(c,i) = forecast_sp(i) × development_category_pct(c)
load(i)              = planned_slice_sp(i) ÷ forecast_sp(i)
```

- Team deduction mode: percentage of available days or fixed days per member/Sprint; defaults can be refined to ceremonies and additional meeting hours at Sprint Planning.
- `fte_factor` handles part-timers and new joiners; default 8 hours/day with Team override. Location-specific holidays and absences apply per member; staggered Team scheduled dates drive each Team's working-day window.
- Overhead-category time is **deducted once**. Training/Retro are not Stories and never receive velocity credit.
- Normalized velocity = `Σ completed development SP ÷ Σ actual development days` for the last four completed Sprints (a ratio of sums, not average of sprint ratios). Use available history, falling back to manual seed if none.
- Development category allocations total 100%, with Team-specific overrides inheriting the Train's defaults when unset; preserve committed allocation history.
- Existing sample/golden cases from the original handoff, including Palawan 291.25 dev days × 0.92 SP/day ≈ 268 SP, remain **illustrative test fixtures for that configured sample cadence**, not globally valid fixed-date rules. Rebuild from a single canonical seed dataset where prototype screenshots disagree.

## 5. Metrics, views and traceability

| Metric | Source |
|---|---|
| Planned vs actual capacity | PI/Sprint **Commitment** capacities vs finalized Actuals, compared at matching planning level |
| Velocity | Actual point-bearing development work completed in Sprint; Story stretch-slice actual points confirmed at Sprint close. Bug counting/point conventions must be clarified in work-item/metrics feature rather than silently excluded |
| Normalized velocity | Four-completed-Sprint rolling ratio of sums (SP / actual dev day) |
| Throughput | Number of work items reaching Done, counted once, by type/category |
| Sprint predictability | **Formula deferred** to operator during M3; must read Sprint Commitment, not latest Plan Version |
| PI predictability | Actual BV relative to planned BV on committed PI objectives (stretch business objectives as in original handoff) |
| Flow efficiency | Active-state time / total cycle time; later confirm state typing and thresholds |

**Board ownership and placement:** Team PI board is Project × Iteration; ART Program Board is Team × Iteration; features stay in their owning Team row. Positions are freehand and view-scoped, while Sprint allocation comes from slices. Internal predecessor edges can cross Teams/Projects, and ExternalDependency records can be displayed in a dedicated Dependencies swimlane. Stretch cards can span columns only **within their PI**. Board warnings are advisory, not blockers.

## 6. Milestone implications

- **M0 Calendar/People/Capacity:** configure variable ART cadence/custom Sprint names, Team one-working-day lead/lag, per-location holidays, and non-story overhead activities. Keep provenance and role placeholders (Admin/RTE/SM) even before RBAC enforcement.
- **M1 Team PI Planning:** separate Story vs Bug types; Project-parented Stories and Bugs; single-Team Features; one-PI constraints; directed cross-Team/Project and external dependencies; full Plan Versions and **Start PI → PI Commitments**.
- **M2 Sprint Execution:** **Start Sprint** review + date picker + commit current plan; **Close Sprint** date picker + confirm Actuals; action timestamps separate from effective and scheduled dates. Workflows, tasks and state history.
- **M3 Metrics:** query `PI Commitment → Sprint Commitment → Actual` and version comparisons without mixing them; operator supplies sprint predictability formula.
- **M4 ART Board:** one Team row per owning Feature; common ART iteration identity with allowed Team offset; cross-Team and outside-ART dependency visualization.

**No further blocking architecture questions.** Defer remaining UI/chart/holiday/state-typing and precise schema details to the respective SDD feature work, without revisiting these settled requirements.
