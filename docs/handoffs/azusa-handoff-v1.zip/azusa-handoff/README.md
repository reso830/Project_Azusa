# Azusa handoff package

Design handoff from Claude to ChatGPT for writing Azusa's feature briefs. **Original Claude design, revised with operator-approved requirements on 2026-11-08.**

**Revision note:** The operator and ChatGPT resolved the architecture review after the original handoff. The updated `AZUSA_HANDOFF.md` (§§7, 10–11, 20–21) and `docs/azusa-data-model.md` (v0.4) incorporate those decisions. They are authoritative over conflicting older prototype assumptions. In particular: configurable ART cadences and one-working-day Team staggers; Story/Bug and ownership constraints; external dependencies; **full Plan Versions vs PI/Sprint Commitments vs Actuals**; and reviewed/backdated Sprint lifecycle actions. The prototype visuals and icon/logo assets have **not** been modified.

**Start with `AZUSA_HANDOFF.md`.** It collates everything: vision, scope, data model, capacity formula, metrics, per-screen specs, design system, icons, stack, milestones, sample data, decisions and open questions.

The prototype is a **jumping board**. Each screen will be refined in its own feature. Where the prototype and `AZUSA_HANDOFF.md` disagree, the handoff doc wins.

| Path | What it is |
|---|---|
| `AZUSA_HANDOFF.md` | The full handoff (copy-paste friendly) |
| `screenshots/*.png` | Renders of every screen at 1440px wide. **Look here for visuals** |
| `prototype/*.dc.html` | Screen source from the Claude design canvas: markup with `{{holes}}`, `<sc-for>` / `<sc-if>`, and a `renderVals()` / `pageVals()` script holding the sample data. Needs the canvas runtime (`support.js`, not included), so read it as source |
| `prototype/canvas.json` | How the screens are laid out on the design canvas |
| `icons/icons.json`, `icons/svg/` | The "Kumiko line" icon set: 24px grid, 1.75 stroke, `currentColor` plus orange `#E07F24` |
| `assets/azusa-logo*.png` | Logo. In the prototype it is referenced as `/_blob/eb2c6d73f86feb942c6986c10c979040` |
| `docs/azusa-data-model.md` | Data model and capacity formula, v0.4 (revised canonical conceptual model; aligned with the handoff §7–§12) |

## Screens

| # | Screen | Source | Screenshot |
|---|---|---|---|
| 1 | Team PI board (Project × Iteration) | `Main.dc.html` | `01-team-pi-board.png`, `01b-…-menu-open.png` |
| 2 | ART program board (Team × Iteration) | `ProgramBoard.dc.html` | `02-art-program-board.png` |
| 3 | Capacity planner | `Capacity.dc.html` | `03-capacity-planner.png` |
| 4 | Team PI brief | `PIBrief.dc.html` | `04-team-pi-brief.png` |
| 5 | Iteration board (Sprint 2706) | `TeamIteration.dc.html` | `05-iteration-board.png` |
| 6 | Team dashboard | `Dashboard.dc.html` | `06-team-dashboard.png` |
| 7 | Settings › Locations and holidays | `Settings.dc.html` | `07-settings-locations-holidays.png` |
| 8 | Icon reference sheet | `Icons.dc.html` | `08-icon-set.png` |

The screenshots were rendered on 2026-11-08, so the header clock shows that date. The sample data is set in PI-2027.1, Sprint 2706 (Feb 2027).
